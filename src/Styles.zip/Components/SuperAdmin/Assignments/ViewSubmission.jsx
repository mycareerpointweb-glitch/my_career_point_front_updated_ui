import React, { useState } from "react";
import { 
    FiSearch, FiX, FiCheckCircle, FiAlertCircle, FiPaperclip, FiArrowLeft
} from "react-icons/fi";
import "../../../Styles/SuperAdmin/Assignment.css"; 

// --- DUMMY DATA STRUCTURES (Provided by User for Context) ---
const DUMMY_BATCHES = [
    { id: 101, courseName: "CA Foundation - Apr 2025 Regular", batchPrefix: "CAF-Apr25R", stream: "CA", level: "Foundation", enrollment: 450, status: "Active" },
    { id: 102, courseName: "CA Foundation - Dec 2025 Fast Track", batchPrefix: "CAF-Dec25FT", stream: "CA", level: "Foundation", enrollment: 210, status: "Active" },
    { id: 105, courseName: "CA Foundation - Nov 2025 Weekend", batchPrefix: "CAF-Nov25W", stream: "CA", level: "Foundation", enrollment: 150, status: "Active" },
    { id: 103, courseName: "CA Intermediate - Apr 2025 Group 1", batchPrefix: "CAI-Apr25G1", stream: "CA", level: "Intermediate", enrollment: 620, status: "Active" },
    { id: 106, courseName: "CA Intermediate - May 2026 Combined", batchPrefix: "CAI-May26C", stream: "CA", level: "Intermediate", enrollment: 410, status: "Active" },
    { id: 201, courseName: "CMA Foundation - Apr 2025 Batch A", batchPrefix: "CMF-Apr25A", stream: "CMA", level: "Foundation", enrollment: 120, status: "Active" },
    { id: 203, courseName: "CMA Intermediate - Apr 2025 Term 1", batchPrefix: "CMI-Apr25T1", stream: "CMA", level: "Intermediate", enrollment: 150, status: "Active" },
    { id: 301, courseName: "CA Advanced - May 2025", batchPrefix: "CAA-May25", stream: "CA", level: "Advanced", enrollment: 500, status: "Active" },
];

const COURSE_SUBJECTS = {
    "CA": {
        "Foundation": [
            { id: 1, code: "CFA01", name: "Principles and Practice of Accounting" },
            { id: 2, code: "CFL02", name: "Business Laws and Business Correspondence and Reporting" },
        ],
        "Intermediate": [
            { id: 5, code: "CIA05", name: "Accounting" },
            { id: 6, code: "CIL06", name: "Corporate and Other Laws" },
        ],
        "Advanced": [
            { id: 16, code: "CAA16", name: "Financial Reporting" },
        ]
    },
    "CMA": {
        "Foundation": [
            { id: 13, code: "CMF13", name: "Fundamentals of Business Laws and Ethics" },
        ],
        "Intermediate": [
            { id: 19, code: "CMI19", name: "Corporate Laws & Compliance" },
        ],
    }
};

// --- DUMMY SUBMISSIONS DATA (Filtered by Assignment ID) ---
const DUMMY_SUBMISSIONS_DATA = [
    // ASSIGNMENT ID 1 (CA Foundation / CFA01)
    { assignmentId: 1, studentId: 9001, studentName: "Aman Sharma", file: "Aman_A1_Acc_Final.pdf", marks: 45, submittedDate: "2025-04-25", validated: true },
    { assignmentId: 1, studentId: 9002, studentName: "Bhavna Singh", file: "Bhavna_A1_Acc_V1.docx", marks: null, submittedDate: "2025-04-26", validated: false },
    
    // ASSIGNMENT ID 2 (CA Foundation / CFL02)
    { assignmentId: 2, studentId: 9004, studentName: "Deepak Verma", file: "Deepak_A2_Law_Case.pdf", marks: 32, submittedDate: "2025-05-14", validated: true },
    { assignmentId: 2, studentId: 9005, studentName: "Esha Gupta", file: "Esha_A2_Law_Draft.pdf", marks: null, submittedDate: "2025-05-15", validated: false },
    
    // ASSIGNMENT ID 5 (CA Intermediate / CIA05)
    { assignmentId: 5, studentId: 9101, studentName: "Gaurav Kohli", file: "Gaurav_A5_InterAcc.docx", marks: 65, submittedDate: "2025-03-20", validated: true },
    { assignmentId: 5, studentId: 9102, studentName: "Hitesh Jain", file: "Hitesh_A5_InterAcc.pdf", marks: 58, submittedDate: "2025-03-21", validated: true },

    // ASSIGNMENT ID 13 (CMA Foundation / CMF13)
    { assignmentId: 13, studentId: 9201, studentName: "Ira Khan", file: "Ira_A13_CMA_Law.pdf", marks: 40, submittedDate: "2025-04-10", validated: true },
    { assignmentId: 13, studentId: 9202, studentName: "Jatin Malik", file: "Jatin_A13_CMA_Law.pdf", marks: 35, submittedDate: "2025-04-11", validated: true },
    
    // ASSIGNMENT ID 16 (CA Advanced / CAA16)
    { assignmentId: 16, studentId: 9301, studentName: "Karan Iyer", file: "Karan_A16_AdvRep.pdf", marks: 80, submittedDate: "2025-05-10", validated: true },
];
// --- END DUMMY DATA ---

const ViewSubmission = ({ stream, level, batchName, subjectName, assignmentId, assignmentTitle, onClose }) => {
    
    const [searchTerm, setSearchTerm] = useState('');
    const MAX_MARKS = 50; // Placeholder Max Marks

    // 🔑 THE CORE FILTER: We only filter by the unique assignmentId received,
    // as it represents the assignment selected within the full Stream/Course/Batch hierarchy.
    const currentAssignmentSubmissions = DUMMY_SUBMISSIONS_DATA.filter(
        sub => sub.assignmentId === assignmentId
    );

    // Apply search filter on student name/ID
    const filteredSubmissions = currentAssignmentSubmissions.filter(sub => {
        if (!searchTerm) return true;
        const searchLower = searchTerm.toLowerCase();
        return (
            sub.studentName.toLowerCase().includes(searchLower) ||
            String(sub.studentId).includes(searchLower)
        );
    });

    return (
        <div className="am_assignment-submissions-section vs_card-container">
            <div className="vs_header-bar">
                {/* Back Button */}
                <button className="btn btn-icon vs_back-button" onClick={onClose} title="Back to Assignments">
                    <FiArrowLeft size={20} />
                </button>
                
                {/* Contextual Title - Uses the passed-in parameters */}
                <div className="vs_title-group">
                    <h4 className="vs_subtitle">
                        Subject - {subjectName}
                    </h4>
                </div>
            </div>

            <div className="vs_detail-panel-content am_detail-panel-content">
                <div className="vs_controls-header am_batch-controls-header">
                    <h4 className="vs_table-header am_detail-header">
                        Assignment Name:: {assignmentTitle} ({currentAssignmentSubmissions.length} Students)
                    </h4>
                    
                    {/* Search Bar */}
                    <div className="vs_search-bar am_search-bar am_batch-search-bar">
                        <FiSearch className="am_search-icon" />
                        <input
                            type="text"
                            placeholder="Search Student Name or ID..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                        {searchTerm && (
                            <FiX className="am_clear-icon" onClick={() => setSearchTerm('')} />
                        )}
                    </div>
                </div>

                {/* Table Display */}
                <div className="vs_table-wrapper am_assignment-table-wrapper" style={{ marginTop: '15px' }}>
                    <table className="am_assignment-table">
                        <thead>
                            <tr>
                                <th>Student Name</th>
                                <th>Student ID</th>
                                <th>Submitted File</th>
                                <th>Marks</th>
                                <th>Submitted Date</th>
                                <th>Validated</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredSubmissions.length > 0 ? (
                                filteredSubmissions.map(sub => (
                                    <tr key={sub.studentId}>
                                        <td>{sub.studentName}</td>
                                        <td>{sub.studentId}</td>
                                        <td className="am_file-cell">
                                            {/* File Icon based on extension */}
                                            <FiPaperclip 
                                                className={`text-${sub.file.includes('.pdf') ? 'error' : sub.file.includes('.docx') ? 'info' : 'warning'}`} 
                                            />
                                            <span className="am_file-cell-text">{sub.file}</span>
                                        </td>
                                        <td>
                                            {sub.marks !== null ? (
                                                <span style={{ fontWeight: 'bold' }}>{sub.marks} / {MAX_MARKS}</span>
                                            ) : (
                                                <span style={{ color: 'var(--color-warning-dark)' }}>Pending</span>
                                            )}
                                        </td>
                                        <td>{sub.submittedDate}</td>
                                        <td>
                                            {sub.validated ? (
                                                <FiCheckCircle size={16} style={{ color: 'var(--color-success-dark)' }} />
                                            ) : (
                                                <FiAlertCircle size={16} style={{ color: 'var(--color-warning-dark)' }} />
                                            )}
                                        </td>
                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td colSpan="6" className="am_no-results-table">
                                        No submissions found or matching search criteria.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default ViewSubmission;