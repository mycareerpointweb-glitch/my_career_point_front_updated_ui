import React, { useState, useEffect, useRef } from "react";
import {
    FiSearch, FiPlus, FiEdit2, FiTrash2, FiUsers,
    FiX, FiChevronLeft, FiChevronRight,
    FiLayers, FiBookOpen, FiAlertTriangle, FiCheckCircle,
    FiClock, FiMapPin, FiCalendar
} from "react-icons/fi";
import "../../Styles/SuperAdmin/Batches.css";

// ⚠️ IMPORTANT: Set the API Base URL to your Express server
// The URL is based on your server running at port 5000 and the '/api/courses' route


const API_BASE_URL = "http://localhost:5000/api/courses";
const teacherOptions = [
    { value: "teacher1", label: "John Doe" },
    { value: "teacher2", label: "Jane Smith" },
    { value: "teacher3", label: "Mark Lee" },
    { value: "teacher4", label: "Priya Sharma" },
    { value: "teacher5", label: "Ahmed Khan" },
];

const dummyCourses = [
    { id: 101, courseName: "CA Foundation - Apr 2025 Regular", batchPrefix: "CAF-Apr25R", stream: "CA", level: "Foundation" },
    { id: 102, courseName: "CA Foundation - Dec 2025 Fast Track", batchPrefix: "CAF-Dec25FT", stream: "CA", level: "Foundation" },
    { id: 105, courseName: "CA Foundation - Nov 2025 Weekend", batchPrefix: "CAF-Nov25W", stream: "CA", level: "Foundation" },
    { id: 108, courseName: "CA Foundation - May 2026 Full", batchPrefix: "CAF-May26F", stream: "CA", level: "Foundation" },
    { id: 110, courseName: "CA Foundation - July 2026 Crash", batchPrefix: "CAF-Jul26C", stream: "CA", level: "Foundation" },

    { id: 103, courseName: "CA Intermediate - Apr 2025 Group 1", batchPrefix: "CAI-Apr25G1", stream: "CA", level: "Intermediate" },
    { id: 104, courseName: "CA Intermediate - Dec 2025 Group 2", batchPrefix: "CAI-Dec25G2", stream: "CA", level: "Intermediate" },
    { id: 106, courseName: "CA Intermediate - May 2026 Combined", batchPrefix: "CAI-May26C", stream: "CA", level: "Intermediate" },
    { id: 107, courseName: "CA Intermediate - July 2025 Weekend", batchPrefix: "CAI-Jul25W", stream: "CA", level: "Intermediate" },

    { id: 201, courseName: "CMA Foundation - Apr 2025 Batch A", batchPrefix: "CMF-Apr25A", stream: "CMA", level: "Foundation" },
    { id: 202, courseName: "CMA Foundation - Nov 2025 Batch B", batchPrefix: "CMF-Nov25B", stream: "CMA", level: "Foundation" },
    { id: 205, courseName: "CMA Foundation - May 2026 Exclusive", batchPrefix: "CMF-May26E", stream: "CMA", level: "Foundation" },
    { id: 203, courseName: "CMA Intermediate - Apr 2025 Term 1", batchPrefix: "CMI-Apr25T1", stream: "CMA", level: "Intermediate" },
    { id: 204, courseName: "CMA Intermediate - Dec 2025 Term 2", batchPrefix: "CMI-Dec25T2", stream: "CMA", level: "Intermediate" },
];

const initialBatches = [
    { 
        id: 1011, 
        courseId: 101, 
        name: "Morning Batch A", 
        startDate: "2025-02-05", 
        endDate: "2025-04-15", 
        instructorIds: ["teacher1", "teacher3"], 
        studentCount: 98, 
        status: "Active", 
        capacity: 100, 
        mode: "Offline", 
        location: "Building A, Room 101", 
        notes: "Regular morning session",
        schedule: { startDay: "Mon", startTime: "09:00", endDay: "Fri", endTime: "12:00" } 
    },
    { 
        id: 1021, 
        courseId: 102, 
        name: "Fast Track Batch", 
        startDate: "2025-10-01", 
        endDate: "2025-11-15", 
        instructorIds: ["teacher2"], 
        studentCount: 15, 
        status: "Upcoming", 
        capacity: 50, 
        mode: "Online", 
        location: "Zoom Link TBD", 
        notes: "Fast-paced course completion",
        schedule: { startDay: "Sat", startTime: "14:00", endDay: "Sun", endTime: "17:00" } 
    },
    { 
        id: 1051, 
        courseId: 105, 
        name: "Weekend Batch", 
        startDate: "2025-08-01", 
        endDate: "2025-11-20", 
        instructorIds: ["teacher5"], 
        studentCount: 50, 
        status: "Upcoming", 
        capacity: 70, 
        mode: "Hybrid", 
        location: "Campus + Google Meet", 
        notes: "Weekend classes only",
        schedule: { startDay: "Sat", startTime: "10:00", endDay: "Sun", endTime: "13:00" } 
    },
    { 
        id: 1031, 
        courseId: 103, 
        name: "Group 1 Regular", 
        startDate: "2025-01-20", 
        endDate: "2025-04-10", 
        instructorIds: ["teacher1", "teacher4"], 
        studentCount: 85, 
        status: "Active", 
        capacity: 100, 
        mode: "Offline", 
        location: "Building B, Hall 5", 
        notes: "Focus on Group 1 topics",
        schedule: { startDay: "Mon", startTime: "10:00", endDay: "Fri", endTime: "13:00" } 
    },
    { 
        id: 1032, 
        courseId: 103, 
        name: "Group 1 Batch 2", 
        startDate: "2025-02-15", 
        endDate: "2025-05-01", 
        instructorIds: ["teacher3"], 
        studentCount: 52, 
        status: "Active", 
        capacity: 60, 
        mode: "Online", 
        location: "Private Discord Server", 
        notes: "Second batch for Group 1",
        schedule: { startDay: "Tue", startTime: "18:00", endDay: "Thu", endTime: "21:00" } 
    },
    { 
        id: 2011, 
        courseId: 201, 
        name: "Regular Batch A", 
        startDate: "2025-02-01", 
        endDate: "2025-04-20", 
        instructorIds: ["teacher1", "teacher3"], 
        studentCount: 62, 
        status: "Active", 
        capacity: 80, 
        mode: "Offline", 
        location: "CMA Campus, Room 3", 
        notes: "Standard CMA Foundation batch",
        schedule: { startDay: "Mon", startTime: "08:00", endDay: "Fri", endTime: "11:00" } 
    },
    { 
        id: 2031, 
        courseId: 203, 
        name: "Term 1 Batch X", 
        startDate: "2025-01-05", 
        endDate: "2025-03-30", 
        instructorIds: ["teacher5", "teacher2"], 
        studentCount: 120, 
        status: "Active", 
        capacity: 130, 
        mode: "Hybrid", 
        location: "Auditorium + Live Stream", 
        notes: "Intensive Term 1 preparation",
        schedule: { startDay: "Wed", startTime: "17:00", endDay: "Fri", endTime: "20:00" } 
    },
];

const modeOptions = [
    { value: "Online", label: "Online" },
    { value: "Offline", label: "Offline" },
    { value: "Hybrid", label: "Hybrid" },
];

const weekDays = [
    { value: "Mon", label: "Monday" },
    { value: "Tue", label: "Tuesday" },
    { value: "Wed", label: "Wednesday" },
    { value: "Thu", label: "Thursday" },
    { value: "Fri", label: "Friday" },
    { value: "Sat", label: "Saturday" },
    { value: "Sun", label: "Sunday" },
];


// --- CustomSelect Component (to replace <select> as requested) ---

// Reusable component for dropdown look and feel using divs
const CustomSelect = ({ label, options, value, onChange, name, placeholder, disabled = false, icon: Icon, required = false }) => {
    const [isOpen, setIsOpen] = useState(false);
    const selectRef = useRef(null);
    const selectedOption = options.find(opt => opt.value === value);
    const selectedLabel = selectedOption?.label || (selectedOption === undefined && value === "" ? placeholder : value);

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (selectRef.current && !selectRef.current.contains(event.target)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const handleOptionClick = (optionValue) => {
        // Mocking the event structure for compatibility with standard input handler
        onChange({ target: { name, value: optionValue } });
        setIsOpen(false);
    };

    const containerClasses = `batch-pro-custom-select ${isOpen ? 'open' : ''} ${disabled ? 'disabled' : ''}`;
    const headerClasses = `batch-pro-selected-value ${!value ? 'placeholder' : ''}`;

    return (
        <div className="batch_form_group" ref={selectRef}>
            <label>{label} {required && '*'}</label>
            <div className={containerClasses} onClick={() => !disabled && setIsOpen(!isOpen)}>
                <div className={headerClasses}>
                    {Icon && <Icon size={16} style={{ marginRight: '8px', color: 'var(--color-gray-500)' }} />}
                    {selectedLabel || placeholder}
                    <FiChevronDown size={18} className="batch-pro-dropdown-icon" />
                </div>
                {isOpen && (
                    <div className="batch-pro-select-dropdown">
                        {/* Option for default/placeholder if not required, or if we want an 'unselect' option */}
                        {placeholder && !required && (
                            <div
                                className="batch-pro-select-option placeholder-option"
                                onClick={(e) => { e.stopPropagation(); handleOptionClick(""); }}
                            >
                                {placeholder}
                            </div>
                        )}
                        {options.map((option) => (
                            <div
                                key={option.value}
                                className={`batch-pro-select-option ${option.value === value ? 'selected' : ''}`}
                                onClick={(e) => { e.stopPropagation(); handleOptionClick(option.value); }}
                            >
                                {option.label}
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

const FiChevronDown = ({ size, className }) => (
    <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="6 9 12 15 18 9"></polyline>
    </svg>
);


// --- Main Batches Component ---

const Batches = () => {
    const [batches, setBatches] = useState(initialBatches);
    // MODIFIED: Initial states are now null, requiring user selection
    const [selectedStream, setSelectedStream] = useState(null); 
    const [selectedLevel, setSelectedLevel] = useState(null);
    const [selectedCourseId, setSelectedCourseId] = useState(null); 
    
    // Global loading state for table (e.g., when fetching all batches, initially true)
    const [loading, setLoading] = useState(true); 
    // New states for form submissions and feedback
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [error, setError] = useState(null);
    const [success, setSuccess] = useState(null);

    const [addBatchOpen, setAddBatchOpen] = useState(false);
    const [addCourseOpen, setAddCourseOpen] = useState(false);
    const [editBatch, setEditBatch] = useState(null);
    const [selectedYear, setSelectedYear] = useState("All Years");
    // FIX: Add the missing searchTerm state here
    const [searchTerm, setSearchTerm] = useState(""); 
    const [selectableCourses, setSelectableCourses] = useState([]);
    const scrollContainer = useRef(null); // Exists for horizontal slider

    // REFS FOR AUTO-SCROLLING
    const levelNavRef = useRef(null);
    const courseSliderRef = useRef(null);
    const batchesSectionRef = useRef(null);

    // Levels are now state to allow dynamic addition
    const [courseLevels, setCourseLevels] = useState(["Foundation", "Intermediate"]);

    const availableYears = ["All Years", "2025", "2026", "2027"];

    const filteredCourses = dummyCourses
        .filter(c => c.stream === selectedStream)
        .filter(c => c.level === selectedLevel);

    useEffect(() => {
        // Simulate initial data loading for the table
        const timer = setTimeout(() => setLoading(false), 500);
        return () => clearTimeout(timer);
    }, []);

    // NEW LOGIC: Filter courses based on Stream/Level selection
    useEffect(() => {
        if (selectedStream && selectedLevel) {
            const courses = dummyCourses.filter(c => c.stream === selectedStream && c.level === selectedLevel);
            setSelectableCourses(courses);
            
            // Check if the current selected course is still valid for the new stream/level
            if (selectedCourseId && courses.findIndex(c => c.id === selectedCourseId) === -1) {
                // If the previous course selection is no longer valid, clear it
                setSelectedCourseId(null);
                setFormData(prev => ({ ...prev, courseId: null }));
            }
            
            if (courses.length === 0) {
                setSelectedCourseId(null);
                setFormData(prev => ({ ...prev, courseId: null }));
            }

        } else {
            // Clear all course related states if stream or level is not selected
            setSelectableCourses([]);
            setSelectedCourseId(null);
            setFormData(prev => ({ ...prev, courseId: null }));
        }
    }, [selectedStream, selectedLevel]); 
    // selectedCourseId removed from dependency array to avoid setting it automatically
    

    // NEW: Scroll to the Level Navigation when a Stream is selected
    useEffect(() => {
        if (selectedStream && levelNavRef.current) {
            levelNavRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, [selectedStream]);

    // NEW: Scroll to the Course Slider when a Level is selected
    useEffect(() => {
        if (selectedLevel && courseSliderRef.current) {
            courseSliderRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, [selectedLevel]);

    // NEW: Scroll to the Batches Table when a Course is selected
    useEffect(() => {
        if (selectedCourseId && batchesSectionRef.current) {
            batchesSectionRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, [selectedCourseId]);
    
    const initialFormData = {
        courseId: null,
        name: "",
        startDate: "", // Overall batch start date
        endDate: "",   // Overall batch end date
        instructorIds: [],
        capacity: "",  // New: Student capacity
        mode: "",      // New: Online/Offline/Hybrid
        location: "",  // New: Location text
        notes: "",     // New: Notes/Description text
        // New: Schedule fields (for daily/weekly class times)
        schedule: {
            startDay: "",
            startTime: "",
            endDay: "",
            endTime: ""
        }
    };

    const [formData, setFormData] = useState(initialFormData);

    // Sync formData's courseId when selection changes
    useEffect(() => {
        if (selectedCourseId) {
            setFormData(prev => ({ ...prev, courseId: selectedCourseId }));
        } else {
             setFormData(prev => ({ ...prev, courseId: null }));
        }
    }, [selectedCourseId]);


    // New state for Add Course Form (Stream and the New Level name)
    const [newCourseForm, setNewCourseForm] = useState({
        stream: selectedStream || 'CA',
        level: '', // This is the new Level name input, e.g., "Executive"
    });

    // Sync newCourseForm stream when main selection changes
    useEffect(() => {
        setNewCourseForm(prev => ({
            ...prev,
            stream: selectedStream || '',
            level: '', // Always clear the new level input when stream changes
        }));
    }, [selectedStream]);

    // Helper to clear feedback messages after a delay
    useEffect(() => {
        if (success || error) {
            const timer = setTimeout(() => {
                setSuccess(null);
                setError(null);
            }, 5000);
            return () => clearTimeout(timer);
        }
    }, [success, error]);


    const handleNewCourseFormChange = (e) => {
        const { name, value } = e.target;
        setNewCourseForm(prev => ({ ...prev, [name]: value }));
    };

    /**
     * HANDLER FOR ADDING NEW COURSE LEVEL
     * Sends a POST request to the backend. (Mocked)
     */
    const handleAddNewCourse = async (e) => {
        e.preventDefault();
        setError(null);
        setSuccess(null);
        const newLevelName = newCourseForm.level.trim();

        if (!newLevelName) {
             setError("Please enter a new course level name.");
             return;
        }

        // Check if level already exists (case-insensitive)
        if (courseLevels.map(l => l.toLowerCase()).includes(newLevelName.toLowerCase())) {
            setError(`The course level "${newLevelName}" already exists.`);
            return;
        }

        const courseData = { 
            stream: newCourseForm.stream, 
            newLevel: newLevelName 
        };

        setIsSubmitting(true);
        try {
            console.log("Sending course level data:", courseData);
            
            // NOTE: API call is commented out, using client-side update only.
            // const response = await fetch(`${API_BASE_URL}/levels/create`, { ... });

            // SIMULATE SUCCESS
            await new Promise(resolve => setTimeout(resolve, 1000));
            // END SIMULATION

            // 3. Update local state ONLY on successful API response
            setCourseLevels(prevLevels => [...prevLevels, newLevelName]);
            setSelectedLevel(newLevelName); // Automatically select the new level

            // 4. Provide feedback and reset form
            setSuccess(`New course level "${newLevelName}" for ${newCourseForm.stream} created successfully!`);
            setAddCourseOpen(false);
            setNewCourseForm({
                stream: selectedStream || 'CA',
                level: '',
            });

        } catch (err) {
            // setError(err.message || 'Failed to add new course level.'); // Use if API is active
            setError('Failed to add new course level (Simulated API failure).'); 
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleStreamClick = (stream) => {
        setSelectedStream(stream);
        // Reset subsequent selections, hiding the next steps
        setSelectedLevel(null); 
        setSelectedCourseId(null);
        setAddBatchOpen(false);
        setSelectedYear("All Years");
        setFormData(prev => ({ ...prev, courseId: null }));
    };

    const handleLevelClick = (level) => {
        setSelectedLevel(level);
        // Reset subsequent selections, hiding the table
        setSelectedCourseId(null); 
        setAddBatchOpen(false);
        setSelectedYear("All Years");
        setFormData(prev => ({ ...prev, courseId: null }));
        
        // The filtering and course list update happens in the useEffect
    };

    const handleCourseSelect = (courseId) => {
        setSelectedCourseId(courseId);
        setFormData(prev => ({ ...prev, courseId }));
    };

    const handleFormChange = (e) => {
        const { name, value } = e.target;
        if (name === "instructorIds") {
            setFormData(prev => ({
                ...prev,
                instructorIds: prev.instructorIds.includes(value)
                    ? prev.instructorIds.filter(id => id !== value)
                    : [...prev.instructorIds, value]
            }));
        } else if (name.startsWith('schedule.')) {
            // Handle nested schedule state
            const scheduleKey = name.split('.')[1];
            setFormData(prev => ({
                ...prev,
                schedule: {
                    ...prev.schedule,
                    [scheduleKey]: value,
                }
            }));
        } else {
            setFormData(prev => ({ ...prev, [name]: value }));
        }
    };

    /**
     * HANDLER FOR ADDING NEW BATCH
     * Sends a POST request to the backend. (Mocked)
     */
    const handleAddBatch = async (e) => {
        e.preventDefault();
        setError(null);
        setSuccess(null);
        
        // --- Validation ---
        if (!formData.name || !formData.startDate || !formData.endDate || !formData.capacity || !formData.mode) {
             setError("Please fill in all required fields (Name, Dates, Capacity, Mode).");
             return;
        }
        if (!formData.courseId) {
             setError("No Course Selected. Please select a course from the slider.");
             return;
        }

        // Basic check for schedule consistency
        if (formData.schedule.startDay && formData.schedule.endDay) {
            const startDayIndex = weekDays.findIndex(d => d.value === formData.schedule.startDay);
            const endDayIndex = weekDays.findIndex(d => d.value === formData.schedule.endDay);
            if (startDayIndex > endDayIndex && formData.startDate === formData.endDate) {
                    setError("If the batch ends on the same day it starts, the schedule end day cannot precede the start day.");
                    return;
            }
        }


        const capacityNum = parseInt(formData.capacity, 10);
        if (isNaN(capacityNum) || capacityNum <= 0) {
             setError("Student Capacity must be a positive number.");
             return;
        }

        // --- Prepare Payload ---
        const newBatch = {
            ...formData,
            id: Date.now(), // Placeholder ID
            studentCount: 0,
            capacity: capacityNum, // Ensure it's a number
            status: formData.startDate > new Date().toISOString().split('T')[0] ? "Upcoming" : "Active",
            courseId: parseInt(formData.courseId),
        };
        
        setIsSubmitting(true);
        try {
            // 1. Send data to backend using fetch POST
            console.log("Sending batch data:", newBatch);
            // const response = await fetch(`${API_BASE_URL}/batches/create`, { ... });

            // SIMULATE SUCCESS
            await new Promise(resolve => setTimeout(resolve, 1000));
            // END SIMULATION
            
            // 3. Update local state ONLY on successful API response
            setBatches(prev => [...prev, newBatch]); // Using client-side object for state update
            
            // 4. Provide feedback and reset form
            setSuccess(`Batch '${newBatch.name}' created successfully!`);
            setAddBatchOpen(false);
            setFormData(initialFormData); // Reset to initial state
            setFormData(prev => ({ ...prev, courseId: selectedCourseId })); // Restore courseId

        } catch (err) {
            // setError(err.message || 'Failed to create new batch.'); // Use if API is active
            setError('Failed to create new batch (Simulated API failure).');
        } finally {
            setIsSubmitting(false);
        }
    };

    const batchesForSelectedCourse = batches
        .filter(b => b.courseId === selectedCourseId)
        .filter(b => b.name.toLowerCase().includes(searchTerm.toLowerCase()))
        .filter(b => {
            if (selectedYear === "All Years") return true;
            return b.startDate.startsWith(selectedYear);
        });

    const getInstructorLabels = (ids) => {
        return ids.map(id => {
            const teacher = teacherOptions.find(opt => opt.value === id);
            return teacher ? teacher.label : id;
        });
    };

    // Find the specific course object for display/context
    const currentCourse = dummyCourses.find(c => c.id === selectedCourseId);

    const scroll = (direction) => {
        if (scrollContainer.current) {
            scrollContainer.current.scrollBy({ left: direction === 'left' ? -350 : 350, behavior: 'smooth' });
        }
    };

    /**
     * HANDLER FOR DELETING A BATCH
     * Sends a DELETE request to the backend. (Mocked)
     */
    const handleDeleteBatch = async (id) => {
        if (!window.confirm("Are you sure you want to delete this batch? This action cannot be undone.")) {
            return;
        }
        
        setError(null);
        setSuccess(null);

        try {
            // SIMULATE SUCCESS
            await new Promise(resolve => setTimeout(resolve, 500));
            // END SIMULATION

            // 3. Update local state ONLY on successful API response
            setBatches(prev => prev.filter(b => b.id !== id));

            // 4. Provide feedback
            setSuccess(`Batch ID ${id} deleted successfully!`);

        } catch (err) {
            setError(`Failed to delete batch ID ${id} (Simulated API failure).`);
        }
    };

    const handleEditBatch = (batch) => {
        // Ensure all required fields exist in the batch object for the form to avoid errors
        const fullBatch = {
            ...batch,
            capacity: batch.capacity || "",
            mode: batch.mode || "",
            location: batch.location || "",
            notes: batch.notes || "",
            // Ensure schedule exists with default values
            schedule: batch.schedule || { startDay: "", startTime: "", endDay: "", endTime: "" },
        };
        setEditBatch(fullBatch);
    };
    
    // Handler for editing the batch state locally in the modal
    const handleEditFormChange = (e) => {
        const { name, value } = e.target;
         if (!editBatch) return; // Safety check

        if (name === "instructorIds") {
             setEditBatch(prev => ({
                 ...prev,
                 instructorIds: prev.instructorIds.includes(value)
                     ? prev.instructorIds.filter(id => id !== value)
                     : [...prev.instructorIds, value]
             }));
        } else if (name.startsWith('schedule.')) {
            // Handle nested schedule state for editing
            const scheduleKey = name.split('.')[1];
            setEditBatch(prev => ({
                ...prev,
                schedule: {
                    ...prev.schedule,
                    [scheduleKey]: value,
                }
            }));
        } else if (name === "capacity") {
             // Basic capacity validation on change for a better UX
             const numValue = value === "" ? "" : parseInt(value, 10);
             if (value === "" || (!isNaN(numValue) && numValue >= 0)) {
                 setEditBatch(prev => ({ ...prev, [name]: value }));
             }
        } else {
            setEditBatch(prev => ({ ...prev, [name]: value }));
        }
    };


    /**
     * HANDLER FOR EDITING/SAVING A BATCH
     * Sends a PUT request to the backend. (Mocked)
     */
    const handleSaveEdit = async (e) => {
        e.preventDefault();
        setError(null);
        setSuccess(null);
        
        // --- Validation ---
         if (!editBatch.name || !editBatch.startDate || !editBatch.endDate || !editBatch.capacity || !editBatch.mode) {
             setError("Please fill in all required fields (Name, Dates, Capacity, Mode).");
             return;
        }

        const capacityNum = parseInt(editBatch.capacity, 10);
        if (isNaN(capacityNum) || capacityNum <= 0) {
             setError("Student Capacity must be a positive number.");
             return;
        }


        // Ensure status and capacity are correctly updated
        const updatedBatch = {
            ...editBatch,
            status: editBatch.startDate > new Date().toISOString().split('T')[0] ? "Upcoming" : "Active",
            capacity: capacityNum,
        };

        setIsSubmitting(true);
        try {
            // 1. Send update request to backend using fetch PUT
            console.log("Saving updated batch:", updatedBatch);
            // const response = await fetch(`${API_BASE_URL}/batches/update/${updatedBatch.id}`, { ... });

            // SIMULATE SUCCESS
            await new Promise(resolve => setTimeout(resolve, 1000));
            // END SIMULATION

            // 3. Update local state ONLY on successful API response
            setBatches(prev => prev.map(b => b.id === updatedBatch.id ? updatedBatch : b));

            // 4. Provide feedback and close modal
            setSuccess(`Batch '${updatedBatch.name}' updated successfully!`);
            setEditBatch(null);

        } catch (err) {
            // setError(err.message || `Failed to save changes for batch '${updatedBatch.name}'.`); // Use if API is active
            setError(`Failed to save changes for batch '${updatedBatch.name}' (Simulated API failure).`);
        } finally {
            setIsSubmitting(false);
        }
    };

    // Helper function for status badge class
    const getStatusClass = (status) => {
        switch (status) {
            case "Active": return "status-active";
            case "Upcoming": return "status-upcoming";
            case "Completed": return "status-completed";
            default: return "";
        }
    }


    return (
        <div className="batch-pro-wrapper">

            {/* Global Success/Error Notification */}
            {(success || error) && (
                <div className={`notification ${success ? 'success' : 'error'}`}>
                    {success && <FiCheckCircle size={20} style={{ marginRight: '8px' }} />}
                    {error && <FiAlertTriangle size={20} style={{ marginRight: '8px' }} />}
                    {success || error}
                    <button className="close-btn" onClick={() => { setSuccess(null); setError(null); }}>
                        <FiX size={16} />
                    </button>
                </div>
            )}
            {/* End Global Notification */}

            {/* Header */}
            <div className="batch-pro-header-main">
                <h2 className="page-title">Batch Management</h2>
                
            </div>

            {/* Stream Selection */}
             <div className="batch-pro-stream-nav">
                <div className="flex">
                    {['CA', 'CMA'].map((stream) => (
                        <div
                            key={stream}
                            className={`batch-pro-nav-card ${stream === selectedStream ? "selected" : ""}`}
                            onClick={() => handleStreamClick(stream)}
                        >
                            <FiBookOpen size={28} />
                            <h3>{stream}</h3>
                            <p>{`${stream === 'CA' ? 10 : 5} Courses Available`}</p>
                        </div>
                    ))}
                </div>
            </div>
            {/* ADD COURSE BUTTON - NEW IMPLEMENTATION */}
            {/* This button is generally available regardless of level selection */}
            <div className="batch-add-course-button" style={{ display: 'flex', justifyContent: 'flex-end' }}>
                <button className="btn-primary-pro" onClick={() => {
                    setAddCourseOpen(true);
                    setError(null); // Clear errors when opening form
                    setSuccess(null);
                }}>
                    <FiPlus /> Add New Course
                </button>
            </div>
            
            {/* Level Selection (Conditional on Stream) */}
            {selectedStream && (
                <div className="batch-pro-level-nav" ref={levelNavRef}> 
                    <div className="flex">
                        {/* Use courseLevels state here for dynamic list */}
                        {courseLevels.map((level) => (
                            <div
                                key={level}
                                className={`batch-pro-nav-card ${level === selectedLevel ? "selected" : ""}`}
                                onClick={() => handleLevelClick(level)}
                            >
                                <FiLayers size={24} />
                                <h4>{level}</h4>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* The Add Batch button should be here, enabled only by course selection */}
            {selectedLevel && filteredCourses.length > 0 && (
                <>
            <div className="batch-add-course-button" style={{ display: 'flex', justifyContent: 'flex-end' }}>
                <button
                    className="btn-primary-pro"
                    onClick={() => {
                        setAddBatchOpen(true);
                        setError(null); // Clear errors when opening form
                        setSuccess(null);
                    }}
                    disabled={!selectedCourseId} // Enabled ONLY when a course is selected
                    title={!selectedCourseId ? "Select a course before adding a batch" : "Add New Batch"}
                >
                    <FiPlus />
                    Add New Batch
                </button>
            </div>
            

            {/* Course Selector Slider (Conditional on Level) */}
             
                <div className="batch-pro-course-slider-group" ref={courseSliderRef}> 
                    <button
                        className="batch-pro-scroll-btn batch-pro-scroll-left"
                        onClick={() => scroll('left')}
                    >
                        <FiChevronLeft />
                    </button>
                    <div ref={scrollContainer} className="batch-pro-course-slider">
                        {filteredCourses.map(course => (
                            <div
                                key={course.id}
                                className={`batch-pro-course-card ${course.id === selectedCourseId ? 'selected' : ''}`}
                                onClick={() => handleCourseSelect(course.id)}
                            >
                                <h4>{course.courseName}</h4>
                                <p>Prefix: {course.batchPrefix} | {course.stream} {course.level}</p>
                            </div>
                        ))}
                    </div>
                    <button
                        className="batch-pro-scroll-btn batch-pro-scroll-right"
                        onClick={() => scroll('right')}
                    >
                        <FiChevronRight />
                    </button>
                </div>
                </>
            )}


            {/* Batches Header/Toolbar & Table (Conditional on Course Selection) */}
            {selectedCourseId && currentCourse && (
                <div ref={batchesSectionRef}> 
                    <div className="batch-pro-toolbar">
                        <h3 className="page-title">{currentCourse.courseName} Batches</h3>

                        {/* Filter & Search Group */}
                        <div className="batch-pro-filter-search">

                            {/* Filter Button / Dropdown */}
                            <div className="batch-pro-filter-select">
                                <select
                                    id="year-filter"
                                    value={selectedYear}
                                    onChange={(e) => setSelectedYear(e.target.value)}
                                >
                                    {availableYears.map(year => (
                                        <option key={year} value={year}>{year}</option>
                                    ))}
                                </select>
                            </div>

                            {/* Search Box */}
                            <div className="batch-pro-search-input">
                                <input
                                    type="text"
                                    placeholder="Search batch name..."
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                />
                                <FiSearch className="batch-pro-search-icon" />
                            </div>

                        </div>
                    </div>

                    {/* Batches Table */}
                    {loading ? (
                         <div className="loading-state">
                            <div className="spinner"></div>
                            <p>Loading batches...</p>
                        </div>
                    ) : (
                        <div className="batch-pro-table-container">
                            <table className="batch-pro-data-table">
                                <thead>
                                    <tr>
                                        <th>Batch Name</th>
                                        <th>Dates</th>
                                        <th>Mode / Location</th> {/* Combined for better space utilization */}
                                        <th>Instructors</th>
                                        <th>Students / Capacity</th> {/* Combined */}
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {batchesForSelectedCourse.length > 0 ? (
                                        batchesForSelectedCourse.map(batch => (
                                            <tr key={batch.id}>
                                                <td>{batch.name}</td>
                                                <td>{batch.startDate} to {batch.endDate}</td>
                                                <td>
                                                     <span className="tag" style={{ backgroundColor: '#e6e6ff', color: '#0000cc', marginRight: '5px' }}>{batch.mode}</span>
                                                     <FiMapPin size={14} style={{ marginRight: '4px', verticalAlign: 'middle' }} />
                                                     {batch.location || 'N/A'}
                                                </td>
                                                <td>
                                                    {getInstructorLabels(batch.instructorIds).map((label, index) => (
                                                        <span key={index} className="tag">{label}</span>
                                                    ))}
                                                </td>
                                                <td>
                                                    <FiUsers size={16} style={{ marginRight: '4px', verticalAlign: 'middle' }} />
                                                    {batch.studentCount} / {batch.capacity}
                                                </td>
                                                <td>
                                                    <span className={`batch-status-badge ${getStatusClass(batch.status)}`}>
                                                        {batch.status}
                                                    </span>
                                                </td>
                                                <td>
                                                    <div className="batch-pro-action-group">
                                                        <button
                                                            className="btn-icon-pro edit"
                                                            title="Edit Batch"
                                                            onClick={() => {
                                                                handleEditBatch(batch);
                                                                setError(null); // Clear errors when opening form
                                                                setSuccess(null);
                                                            }}
                                                        >
                                                            <FiEdit2 size={16} />
                                                        </button>
                                                        <button
                                                            className="btn-icon-pro delete"
                                                            title="Delete Batch"
                                                            onClick={() => handleDeleteBatch(batch.id)}
                                                        >
                                                            <FiTrash2 size={16} />
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))
                                    ) : (
                                        <tr>
                                            <td colSpan="7" className="empty-state">
                                                <p>No batches found for this course. Try adding a new one.</p>
                                            </td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>
            )}

            {/* Add Batch Modal */}
            {addBatchOpen && (
                <div className="modal-overlay">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h3>Add New Batch</h3>
                            <button className="close-btn" onClick={() => setAddBatchOpen(false)} disabled={isSubmitting}>
                                <FiX size={20} />
                            </button>
                        </div>
                        {error && <div className="form-error"><FiAlertTriangle/> {error}</div>}
                        <form onSubmit={handleAddBatch}>
                            
                            {/* Course / Name / Capacity Row */}
                            <div className="form-row">
                                {/* Read-only display of Stream - Level (Course Context) */}
                                <div className="batch_form_group" style={{ flex: 1.5 }}>
                                    <label>Selected Course Level</label>
                                    <div
                                        style={{
                                            padding: '10px',
                                            border: '1px solid var(--color-gray-300, #e0e0e0)',
                                            borderRadius: 'var(--border-radius-sm, 4px)',
                                            backgroundColor: 'var(--color-gray-100, #f5f5f5)',
                                            color: 'var(--color-gray-700, #4f4f4f)',
                                            fontWeight: 'var(--font-weight-semibold, 600)',
                                            fontSize: 'var(--font-size-md, 16px)',
                                        }}
                                    >
                                        {currentCourse ?
                                            `${currentCourse.stream} - ${currentCourse.level}` :
                                            'Course Level Not Selected'
                                        }
                                    </div>
                                    <input type="hidden" name="courseId" value={formData.courseId || ''} required />
                                </div>
                                <div className="batch_form_group" style={{ flex: 2 }}>
                                    <label>Batch Name *</label>
                                    <input
                                        type="text"
                                        name="name"
                                        value={formData.name}
                                        onChange={handleFormChange}
                                        placeholder="E.g., Morning Batch A"
                                        required
                                        disabled={isSubmitting}
                                    />
                                </div>
                                {/* New Field: Student Capacity */}
                                <div className="batch_form_group" style={{ flex: 1 }}>
                                    <label>Capacity *</label>
                                    <input
                                        type="number"
                                        name="capacity"
                                        value={formData.capacity}
                                        onChange={handleFormChange}
                                        placeholder="Max Students"
                                        min="1"
                                        required
                                        disabled={isSubmitting}
                                    />
                                </div>
                            </div>
                            
                            {/* Dates Row */}
                            <div className="form-row">
                                <div className="batch_form_group">
                                    <label>Batch Start Date *</label>
                                    <input
                                        type="date"
                                        name="startDate"
                                        value={formData.startDate}
                                        onChange={handleFormChange}
                                        required
                                        disabled={isSubmitting}
                                    />
                                </div>
                                <div className="batch_form_group">
                                    <label>Batch End Date *</label>
                                    <input
                                        type="date"
                                        name="endDate"
                                        value={formData.endDate}
                                        onChange={handleFormChange}
                                        required
                                        disabled={isSubmitting}
                                    />
                                </div>
                            </div>
                            
                            {/* Schedule Row */}
                            <div className="form-row">
                                <CustomSelect
                                    label="Schedule Start Day"
                                    name="schedule.startDay"
                                    options={weekDays}
                                    value={formData.schedule.startDay}
                                    onChange={handleFormChange}
                                    placeholder="Select Day"
                                    disabled={isSubmitting}
                                    icon={FiCalendar}
                                />
                                <div className="batch_form_group">
                                    <label>Start Time</label>
                                    <input
                                        type="time"
                                        name="schedule.startTime"
                                        value={formData.schedule.startTime}
                                        onChange={handleFormChange}
                                        disabled={isSubmitting}
                                    />
                                </div>
                                <CustomSelect
                                    label="Schedule End Day"
                                    name="schedule.endDay"
                                    options={weekDays}
                                    value={formData.schedule.endDay}
                                    onChange={handleFormChange}
                                    placeholder="Select Day"
                                    disabled={isSubmitting}
                                    icon={FiCalendar}
                                />
                                <div className="batch_form_group">
                                    <label>End Time</label>
                                    <input
                                        type="time"
                                        name="schedule.endTime"
                                        value={formData.schedule.endTime}
                                        onChange={handleFormChange}
                                        disabled={isSubmitting}
                                    />
                                </div>
                            </div>

                            {/* Mode / Location Row */}
                            <div className="form-row">
                                {/* New Field: Mode (Custom Dropdown) */}
                                <CustomSelect
                                    label="Mode *"
                                    name="mode"
                                    options={modeOptions}
                                    value={formData.mode}
                                    onChange={handleFormChange}
                                    placeholder="Select Mode"
                                    required
                                    disabled={isSubmitting}
                                    icon={FiLayers}
                                />
                                
                                {/* New Field: Location */}
                                <div className="batch_form_group">
                                    <label>Location</label>
                                    <input
                                        type="text"
                                        name="location"
                                        value={formData.location}
                                        onChange={handleFormChange}
                                        placeholder="E.g., Offline Campus A / Zoom Link"
                                        disabled={isSubmitting}
                                    />
                                </div>
                            </div>

                            {/* Instructors */}
                            <div className="batch_form_group">
                                <label>Instructors</label>
                                <div className="batch-pro-checkbox-group">
                                    {teacherOptions.map(teacher => (
                                        <label key={teacher.value} className="checkbox-label">
                                            <input
                                                type="checkbox"
                                                name="instructorIds"
                                                value={teacher.value}
                                                checked={formData.instructorIds.includes(teacher.value)}
                                                onChange={handleFormChange}
                                                disabled={isSubmitting}
                                            />
                                            {teacher.label}
                                        </label>
                                    ))}
                                </div>
                            </div>
                            
                            {/* New Field: Notes */}
                            <div className="batch_form_group">
                                <label>Notes</label>
                                <textarea
                                    name="notes"
                                    value={formData.notes}
                                    onChange={handleFormChange}
                                    placeholder="Any specific details, prerequisites, or internal remarks."
                                    rows="3"
                                    disabled={isSubmitting}
                                />
                            </div>

                            <div className="batch_form_actions">
                                <button type="button"
                                    className="btn-outline-pro"
                                    onClick={() => setAddBatchOpen(false)}
                                    disabled={isSubmitting}>
                                    Cancel
                                </button>
                                <button type="submit"
                                    className="btn-primary-pro"
                                    disabled={isSubmitting}>
                                    {isSubmitting ? 'Creating...' : <><FiPlus/> Create Batch</>}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* Edit Batch Modal (Updated to include new fields and use handleEditFormChange) */}
            {editBatch && (
                <div className="modal-overlay">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h3>Edit Batch: {editBatch.name}</h3>
                            <button className="close-btn" onClick={() => setEditBatch(null)} disabled={isSubmitting}>
                                <FiX size={20} />
                            </button>
                        </div>
                        {error && <div className="form-error"><FiAlertTriangle/> {error}</div>}
                        <form onSubmit={handleSaveEdit}>
                            
                            {/* Course / Name / Capacity Row */}
                            <div className="form-row">
                                <div className="batch_form_group" style={{ flex: 1.5 }}>
                                    <label>Course</label>
                                    <select
                                        name="courseId"
                                        value={editBatch.courseId}
                                        onChange={handleEditFormChange}
                                        required
                                        disabled
                                    >
                                        {dummyCourses.map(course => (
                                            <option key={course.id} value={course.id}>{course.courseName}</option>
                                        ))}
                                    </select>
                                </div>
                                <div className="batch_form_group" style={{ flex: 2 }}>
                                    <label>Batch Name *</label>
                                    <input
                                        type="text"
                                        name="name"
                                        value={editBatch.name}
                                        onChange={handleEditFormChange}
                                        required
                                        disabled={isSubmitting}
                                    />
                                </div>
                                <div className="batch_form_group" style={{ flex: 1 }}>
                                    <label>Capacity *</label>
                                    <input
                                        type="number"
                                        name="capacity"
                                        value={editBatch.capacity}
                                        onChange={handleEditFormChange}
                                        placeholder="Max Students"
                                        min="1"
                                        required
                                        disabled={isSubmitting}
                                    />
                                </div>
                            </div>
                            
                            {/* Dates Row */}
                            <div className="form-row">
                                <div className="batch_form_group">
                                    <label>Batch Start Date *</label>
                                    <input
                                        type="date"
                                        name="startDate"
                                        value={editBatch.startDate}
                                        onChange={handleEditFormChange}
                                        required
                                        disabled={isSubmitting}
                                    />
                                </div>
                                <div className="batch_form_group">
                                    <label>Batch End Date *</label>
                                    <input
                                        type="date"
                                        name="endDate"
                                        value={editBatch.endDate}
                                        onChange={handleEditFormChange}
                                        required
                                        disabled={isSubmitting}
                                    />
                                </div>
                            </div>
                            
                            {/* Schedule Row */}
                            <div className="form-row">
                                <CustomSelect
                                    label="Schedule Start Day"
                                    name="schedule.startDay"
                                    options={weekDays}
                                    value={editBatch.schedule.startDay}
                                    onChange={handleEditFormChange}
                                    placeholder="Select Day"
                                    disabled={isSubmitting}
                                    icon={FiCalendar}
                                />
                                <div className="batch_form_group">
                                    <label>Start Time</label>
                                    <input
                                        type="time"
                                        name="schedule.startTime"
                                        value={editBatch.schedule.startTime}
                                        onChange={handleEditFormChange}
                                        disabled={isSubmitting}
                                    />
                                </div>
                                <CustomSelect
                                    label="Schedule End Day"
                                    name="schedule.endDay"
                                    options={weekDays}
                                    value={editBatch.schedule.endDay}
                                    onChange={handleEditFormChange}
                                    placeholder="Select Day"
                                    disabled={isSubmitting}
                                    icon={FiCalendar}
                                />
                                <div className="batch_form_group">
                                    <label>End Time</label>
                                    <input
                                        type="time"
                                        name="schedule.endTime"
                                        value={editBatch.schedule.endTime}
                                        onChange={handleEditFormChange}
                                        disabled={isSubmitting}
                                    />
                                </div>
                            </div>
                            
                            {/* Mode / Location Row */}
                            <div className="form-row">
                                {/* Field: Mode (Custom Dropdown) */}
                                <CustomSelect
                                    label="Mode *"
                                    name="mode"
                                    options={modeOptions}
                                    value={editBatch.mode}
                                    onChange={handleEditFormChange}
                                    placeholder="Select Mode"
                                    required
                                    disabled={isSubmitting}
                                    icon={FiLayers}
                                />
                                
                                {/* Field: Location */}
                                <div className="batch_form_group">
                                    <label>Location</label>
                                    <input
                                        type="text"
                                        name="location"
                                        value={editBatch.location}
                                        onChange={handleEditFormChange}
                                        placeholder="E.g., Offline Campus A / Zoom Link"
                                        disabled={isSubmitting}
                                    />
                                </div>
                            </div>

                             <div className="batch_form_group">
                                <label>Instructors</label>
                                <div className="batch-pro-checkbox-group">
                                    {teacherOptions.map(teacher => (
                                        <label key={teacher.value} className="checkbox-label">
                                            <input
                                                type="checkbox"
                                                name="instructorIds"
                                                value={teacher.value}
                                                checked={editBatch.instructorIds.includes(teacher.value)}
                                                onChange={handleEditFormChange}
                                                disabled={isSubmitting}
                                            />
                                            {teacher.label}
                                        </label>
                                    ))}
                                </div>
                            </div>

                            {/* Field: Notes */}
                            <div className="batch_form_group">
                                <label>Notes</label>
                                <textarea
                                    name="notes"
                                    value={editBatch.notes}
                                    onChange={handleEditFormChange}
                                    placeholder="Any specific details, prerequisites, or internal remarks."
                                    rows="3"
                                    disabled={isSubmitting}
                                />
                            </div>

                            <div className="batch_form_actions">
                                <button type="button"
                                    className="btn-outline-pro"
                                    onClick={() => setEditBatch(null)}
                                    disabled={isSubmitting}>
                                    Cancel
                                </button>
                                <button type="submit"
                                    className="btn-primary-pro"
                                    disabled={isSubmitting}>
                                    {isSubmitting ? 'Saving...' : 'Save Changes'}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
            
            {/* Add Course Level Modal */}
             {addCourseOpen && (
                <div className="modal-overlay">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h3>Add New Course</h3>
                            <button
                                className="close-btn"
                                onClick={() => {
                                    setAddCourseOpen(false);
                                    // Reset form data on close
                                    setNewCourseForm({
                                        stream: selectedStream || '',
                                        level: '',
                                    });
                                }}
                                disabled={isSubmitting}
                            >
                                <FiX size={20} />
                            </button>
                        </div>
                        {error && <div className="form-error"><FiAlertTriangle/> {error}</div>}
                        <form onSubmit={handleAddNewCourse}>
                            <div className="batch_form_group">
                                <label>Selected Stream (CA or CMA)</label>
                                <input
                                    type="text"
                                    name="stream"
                                    value={newCourseForm.stream}
                                    required
                                    disabled
                                    style={{ backgroundColor: 'var(--color-gray-100)', fontWeight: 'var(--font-weight-semibold)' }}
                                />
                            </div>

                            <div className="batch_form_group">
                                <label>New Course Level</label>
                                <input
                                    type="text"
                                    name="level"
                                    value={newCourseForm.level}
                                    onChange={handleNewCourseFormChange}
                                    placeholder="Enter New Level Name (e.g., Executive, Final)"
                                    required
                                    disabled={isSubmitting}
                                />
                            </div>

                            <div className="batch_form_actions" style={{ marginTop: '20px' }}>
                                <button type="button"
                                    className="btn-outline-pro"
                                    onClick={() => setAddCourseOpen(false)}
                                    disabled={isSubmitting}>
                                    Cancel
                                </button>
                                <button type="submit"
                                    className="btn-primary-pro"
                                    disabled={isSubmitting}>
                                    {isSubmitting ? 'Saving...' : <><FiPlus/> Save Level</>}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Batches;