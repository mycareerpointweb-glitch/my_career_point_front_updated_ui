import "../../Styles/SuperAdmin/AttendanceManagement.css";
import React, { useState, useMemo, useRef, useEffect, useCallback } from 'react';

// Using lucide-react for modern, clean icons
import { 
    Users, BookOpen, Search, 
    MonitorCheck, UserCog, ShieldCheck, 
    Layers, Aperture, TrendingUp,       
    ChevronLeft, ChevronRight, 
    ChevronDown ,
    CalendarCheck, User, Check, X, Filter, BarChart2, List, Calendar, FileDown
} from 'lucide-react';

// --- DUMMY DATA ---
const DUMMY_BATCHES = [
    { id: 101, courseName: "CA Foundation - Apr 2025 Regular", batchPrefix: "CAF-Apr25R", stream: "CA", level: "Foundation", enrollment: 450, status: "Active" },
    { id: 103, courseName: "CA Intermediate - Apr 2025 Group 1", batchPrefix: "CAI-Apr25G1", stream: "CA", level: "Intermediate", enrollment: 620, status: "Active" },
    { id: 201, courseName: "CMA Foundation - Apr 2025 Batch A", batchPrefix: "CMF-Apr25A", stream: "CMA", level: "Foundation", enrollment: 120, status: "Active" },
];

const ROLES = [
    { id: 'Student', label: 'Student', description: 'Mark or view student attendance.', icon: MonitorCheck }, 
    { id: 'Teacher', label: 'Teacher', description: 'Manage your class attendance.', icon: UserCog }, 
    { id: 'Admin', label: 'Admin', description: 'Overview and global settings.', icon: ShieldCheck }, 
];

const STREAMS = [
    { id: 'CA', label: 'CA', description: 'Chartered Accountancy', icon: BookOpen },       
    { id: 'CMA', label: 'CMA', description: 'Cost Management Accountancy', icon: BookOpen },   
];

const LEVELS = [
    { id: 'Foundation', label: 'Foundation', description: 'Entry level courses.', icon: Layers }, 
    { id: 'Intermediate', label: 'Intermediate', description: 'Second stage courses.', icon: Aperture },     
    { id: 'Advanced', label: 'Advanced', description: 'Final/Advanced courses.', icon: TrendingUp }, 
];

const GENDER_OPTIONS = [
    { label: 'All Genders', value: 'All' },
    { label: 'Male', value: 'Male' },
    { label: 'Female', value: 'Female' },
];

const DUMMY_STUDENTS = [
    { id: 1, rollNo: 'CAF001', name: 'Alok Kumar Sharma', gender: 'Male', profile: 'A' },
    { id: 2, rollNo: 'CAF002', name: 'Bhavana Singh', gender: 'Female', profile: 'B' },
    { id: 3, rollNo: 'CAF003', name: 'Chirag Gupta', gender: 'Male', profile: 'C' },
    { id: 4, rollNo: 'CAF004', name: 'Deepika Jain', gender: 'Female', profile: 'D' },
    { id: 5, rollNo: 'CAF005', name: 'Eshwar Reddy', gender: 'Male', profile: 'E' },
    { id: 6, rollNo: 'CAF006', name: 'Fatima Khan', gender: 'Female', profile: 'F' },
    { id: 7, rollNo: 'CAF007', name: 'Gaurav Dubey', gender: 'Male', profile: 'G' },
    { id: 8, rollNo: 'CAF008', name: 'Hima Bindu', gender: 'Female', profile: 'H' },
    { id: 9, rollNo: 'CAF009', name: 'Ishan Verma', gender: 'Male', profile: 'I' },
];

// Helper to generate the last 7 calendar days
const generateCurrentWeekDays = () => {
    const dates = [];
    for (let i = 6; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        dates.push({
            date: date,
            label: date.getDate(),
            isToday: i === 0,
            fullDate: date.toISOString().split('T')[0],
            dayOfWeek: date.toLocaleDateString('en-US', { weekday: 'narrow' })
        });
    }
    return dates;
};

// **UPDATED:** Helper to generate days from the 1st of the current month to today
const generateFullDays = () => {
    const dates = [];
    const today = new Date();
    
    // Set start date to the 1st of the current month at midnight
    const startDate = new Date(today.getFullYear(), today.getMonth(), 1); 

    let currentDate = startDate;
    while (currentDate <= today) {
        dates.push({
            date: new Date(currentDate), // Clone date object
            label: currentDate.getDate(),
            isToday: currentDate.toISOString().split('T')[0] === today.toISOString().split('T')[0],
            fullDate: currentDate.toISOString().split('T')[0],
            dayOfWeek: currentDate.toLocaleDateString('en-US', { weekday: 'narrow' })
        });
        currentDate.setDate(currentDate.getDate() + 1);
    }
    return dates;
};

// Helper to generate random dummy attendance for a given range
const generateDummyAttendance = (students, allDays) => {
    const attendance = {};
    allDays.forEach(day => {
        students.forEach(student => {
            if (!attendance[student.id]) {
                attendance[student.id] = {};
            }
            // Generate P or A randomly for all days
            attendance[student.id][day.fullDate] = Math.random() > 0.3 ? 'P' : 'A';
        });
    });
    return attendance;
};


// --- Custom Dropdown Component (Replaces <select>) ---
const CustomDropdown = ({ options, value, onChange, placeholder, icon: Icon }) => {
    const [isOpen, setIsOpen] = useState(false);
    const dropdownRef = useRef(null);
    
    const selectedOption = options.find(opt => opt.value === value) || options[0];

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const handleSelect = (optionValue) => {
        onChange(optionValue);
        setIsOpen(false);
    };

    return (
        <div className="atm_custom-dropdown-container" ref={dropdownRef}>
            <div className={`atm_custom-dropdown-display ${isOpen ? 'open' : ''}`} onClick={() => setIsOpen(!isOpen)}>
                {Icon && <Icon size={16} className="atm_dropdown-icon" />}
                {selectedOption.label || placeholder}
                <ChevronDown size={16} className="atm_dropdown-chevron" />
            </div>
            {isOpen && (
                <div className="atm_custom-dropdown-options">
                    {options.map((option) => (
                        <div 
                            key={option.value} 
                            className={`atm_custom-dropdown-option ${option.value === value ? 'selected' : ''}`}
                            onClick={() => handleSelect(option.value)}
                        >
                            {option.label}
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};


// --- Sub-Components (omitted for brevity, assume correct) ---
const NavCard = ({ item, selectedId, onSelect, Icon, themeClass }) => {
    const isSelected = item.id === selectedId;
    const selectedClass = isSelected ? themeClass : '';
    
    return (
        <div
            className={`atm_nav-card ${selectedClass}`}
            onClick={() => onSelect(item.id)}
            role="button"
            aria-pressed={isSelected}
        >
            {Icon && <Icon className="atm_nav-card-icon" size={28} />} 
            <h3>{item.label}</h3>
            {item.description && <p>{item.description}</p>} 
        </div>
    );
};

const BatchCard = ({ batch, isSelected, onSelect }) => (
    <div
        className={`atm_batch-card ${isSelected ? 'atm_selected' : ''}`}
        onClick={() => onSelect(batch.id)}
        role="button"
        aria-pressed={isSelected}
    >
        <div className="atm_batch-card-title">{batch.courseName}</div>
        <div className="atm_batch-card-details">
            <CalendarCheck size={12} style={{ display: 'inline-block', marginRight: '4px' }} />
            Batch Code: {batch.batchPrefix}
        </div>
        <div className="atm_batch-card-details">
            <Users size={12} style={{ display: 'inline-block', marginRight: '4px' }} />
            Enrolled: {batch.enrollment}
        </div>
        <span className="atm_badge">{batch.level}</span>
    </div>
);

const StatsCard = ({ title, value, icon: Icon, colorClass }) => (
    <div className={`atm_stats-card ${colorClass}`}>
        <div className="atm_stats-content">
            <p className="atm_stats-title">{title}</p>
            <h3 className="atm_stats-value">{value}</h3>
        </div>
        <Icon size={32} className="atm_stats-icon" />
    </div>
);


// --- Attendance Table Component ---
const AttendanceTable = ({ students, attendanceData, days, toggleAttendance, viewMode, toggleViewMode }) => {
    const todayFullDate = days.find(d => d.isToday)?.fullDate;
    const scrollRef = useRef(null);

    // Scroll to the "Today" column on initial load or view change
    useEffect(() => {
        if (scrollRef.current && viewMode === 'week') {
            // No need to scroll if it's week view (already visible)
        } else if (scrollRef.current && viewMode === 'full') {
            // Scroll all the way to the right (Today) when switching to full view
            scrollRef.current.scrollLeft = scrollRef.current.scrollWidth;
        }
    }, [days, viewMode]);

    return (
        <div className="atm_table-container">
            <div className="atm_table-responsive-wrapper" ref={scrollRef}>
                <table className="atm_attendance-table">
                    <thead>
                        <tr className="atm_attendance-table-backgroundcolor">
                            <th>Student Name (Roll No)</th>
                            <th>Gender</th>
                            {days.map(day => (
                                <th 
                                    key={day.fullDate} 
                                    className={day.isToday ? 'atm_today-header' : ''}
                                    title={day.date.toLocaleDateString()}
                                >
                                    {day.label}
                                    <span className="atm_day-of-week">{day.dayOfWeek}</span>
                                </th>
                            ))}
                            {/* NEW: Toggle column in header */}
                            <th 
                                className={`atm_view-toggle-header atm_view-mode-${viewMode}`}
                                onClick={toggleViewMode}
                                title={viewMode === 'week' ? `Show Full Month History (${days.length} Days)` : 'Show Current Week (7 Days)'}
                            >
                                {viewMode === 'week' ? <List size={18} /> : <Calendar size={18} />}
                                <span className="atm_toggle-label">
                                    {viewMode === 'week' ? 'Monthly' : 'Weekly'}
                                </span>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        {students.length === 0 ? (
                            <tr><td colSpan={days.length + 3} className="atm_no-data">No students found matching the filter criteria.</td></tr>
                        ) : (
                            students.map(student => (
                                <tr key={student.id}>
                                    <td className="atm_sticky-col">
                                        <div className="atm_student-name-cell">
                                            <span className="atm_profile-icon">{student.profile}</span>
                                            <div>
                                                <strong>{student.name}</strong>
                                                <p className="atm_roll-no">{student.rollNo}</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td>{student.gender}</td>
                                    {days.map(day => {
                                        const status = attendanceData[student.id]?.[day.fullDate] || 'A';
                                        
                                        return (
                                            <td 
                                                key={day.fullDate}
                                                className={`atm_status-cell ${day.isToday ? 'atm_today-cell' : ''}`}
                                                onClick={() => day.isToday && toggleAttendance(student.id, todayFullDate)}
                                            >
                                                {day.isToday ? (
                                                    // Present Day Marking
                                                    <span className={`atm_today-status atm_status-${status.toLowerCase()}`}>
                                                        {status === 'P' ? <Check size={18} /> : <X size={18} />}
                                                    </span>
                                                ) : (
                                                    // Past Day Display
                                                    <span className={`atm_status-text atm_status-${status.toLowerCase()}`}>
                                                        {status}
                                                    </span>
                                                )}
                                            </td>
                                        );
                                    })}
                                    {/* Placeholder for the last column to maintain structure */}
                                    <td className="atm_toggle-placeholder-col"></td> 
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

// --- Main Component ---
const AttendanceManagement = ({ userRole }) => {
    const getInitialRole = () => {
        // Only set it to userRole if it's 'Teacher', otherwise start as null.
        return userRole === 'Teacher' ? "Student" : null;
        
    };
    const getInitialStream   = () => {
        // Only set it to userRole if it's 'Teacher', otherwise start as null.
        return userRole === 'Teacher' ? "CA" : null;

    };
    const getInitialCourse   = () => {
        // Only set it to userRole if it's 'Teacher', otherwise start as null.
        return userRole === 'Teacher' ? "Foundation" : null;

    };
    const getInitialBatch   = () => {
        // Only set it to userRole if it's 'Teacher', otherwise start as null.
        return userRole === 'Teacher' ? 101 : null;

    };

    const [selectedRole, setSelectedRole] = useState(getInitialRole)
    const [selectedStream, setSelectedStream] = useState(getInitialStream);
    const [selectedLevel, setSelectedLevel] = useState(getInitialCourse);
    const [selectedBatchId, setSelectedBatchId] = useState(getInitialBatch);
    const [searchTerm, setSearchTerm] = useState('');

    // Stage 2 Attendance States
    const [students, setStudents] = useState([]);
    const [attendanceData, setAttendanceData] = useState({});
    const [searchTermStudents, setSearchTermStudents] = useState('');
    const [genderFilter, setGenderFilter] = useState('All');
    const [viewMode, setViewMode] = useState('week'); // 'week' or 'full' (now month)

    // Initial Data Setup
    const [weekDays] = useState(generateCurrentWeekDays());
    const [fullDays] = useState(generateFullDays());
    
    // Determine which days array to use based on viewMode
    const days = viewMode === 'full' ? fullDays : weekDays;
    const todayFullDate = days.find(d => d.isToday)?.fullDate;
    
    // --- Data Filtering Logic (Stage 1 & 2) ---
    // (Omitted for brevity, assume correct)
    const filteredBatches = useMemo(() => {
        let batches = DUMMY_BATCHES;
        if (selectedStream) {
            batches = batches.filter(batch => batch.stream === selectedStream);
        }
        if (selectedLevel) {
            batches = batches.filter(batch => batch.level === selectedLevel);
        }
        if (searchTerm) {
            const lowerCaseSearch = searchTerm.toLowerCase();
            batches = batches.filter(batch => 
                batch.courseName.toLowerCase().includes(lowerCaseSearch) ||
                batch.batchPrefix.toLowerCase().includes(lowerCaseSearch)
            );
        }
        return batches;
    }, [selectedStream, selectedLevel, searchTerm]);

    const filteredStudents = useMemo(() => {
        let list = students;
        
        if (searchTermStudents) {
            const lowerCaseSearch = searchTermStudents.toLowerCase();
            list = list.filter(student => 
                student.name.toLowerCase().includes(lowerCaseSearch) ||
                student.rollNo.toLowerCase().includes(lowerCaseSearch)
            );
        }

        if (genderFilter !== 'All') {
            list = list.filter(student => student.gender === genderFilter);
        }

        return list;
    }, [students, searchTermStudents, genderFilter]);

    const stats = useMemo(() => {
        const presentToday = filteredStudents.filter(student => 
            attendanceData[student.id]?.[todayFullDate] === 'P'
        ).length;
        
        const total = students.length;
        const filteredCount = filteredStudents.length;

        return {
            total: total,
            presentToday: presentToday,
            absentToday: filteredCount - presentToday,
            filteredCount: filteredCount
        };
    }, [students, filteredStudents, attendanceData, todayFullDate]);


    // --- Stage 2 Handlers & Effects ---
    useEffect(() => {
        if (selectedBatchId) {
            setStudents(DUMMY_STUDENTS);
            setAttendanceData(generateDummyAttendance(DUMMY_STUDENTS, fullDays)); 
            setViewMode('week'); 
        } else {
            setStudents([]);
            setAttendanceData({});
        }
    }, [selectedBatchId, fullDays]);


    const toggleAttendance = useCallback((studentId, date) => {
        setAttendanceData(prevData => {
            const currentStatus = prevData[studentId]?.[date] || 'A';
            const newStatus = currentStatus === 'P' ? 'A' : 'P';
            
            return {
                ...prevData,
                [studentId]: {
                    ...prevData[studentId],
                    [date]: newStatus
                }
            };
        });
    }, []);

    const toggleViewMode = () => {
        setViewMode(prevMode => prevMode === 'week' ? 'full' : 'week');
    };

    // Placeholder for Excel Export
    const handleExportExcel = () => {
        alert("Exporting data to Excel for the current batch...");
        // In a real application, this would trigger an API call to generate and download the CSV/XLSX file.
    };

    // --- Stage 1 Handlers (omitted for brevity, assume correct) ---
    const handleRoleSelect = (roleId) => {
        setSelectedRole(roleId);
        setSelectedStream(null);
        setSelectedLevel(null);
        setSelectedBatchId(null);
        setSearchTerm('');
    };

    const handleStreamSelect = (streamId) => {
        setSelectedStream(streamId);
        setSelectedLevel(null);
        setSelectedBatchId(null);
    };
    
    const handleLevelSelect = (levelId) => {
        setSelectedLevel(levelId);
        setSelectedBatchId(null);
    };

    const handleBatchSelect = (batchId) => {
        console.log(batchId);
        setSelectedBatchId(batchId);
    };

    // --- Slider Controls (omitted for brevity, assume correct) ---
    const sliderRef = useRef(null);
    const [showControls, setShowControls] = useState(false);
    const [canScrollLeft, setCanScrollLeft] = useState(false);
    const [canScrollRight, setCanScrollRight] = useState(false);

    const checkScrollState = useCallback(() => {
        const slider = sliderRef.current;
        if (slider) {
            const isOverflowing = slider.scrollWidth > slider.clientWidth;
            if (window.innerWidth > 768) {
                 setShowControls(isOverflowing);
            } else {
                 setShowControls(false);
            }
            setCanScrollLeft(slider.scrollLeft > 5);
            setCanScrollRight(slider.scrollLeft < slider.scrollWidth - slider.clientWidth - 5);
        }
    }, []);

    useEffect(() => {
        setTimeout(checkScrollState, 100);
        const slider = sliderRef.current;
        if (slider) {
            slider.addEventListener('scroll', checkScrollState);
            window.addEventListener('resize', checkScrollState);
            return () => {
                slider.removeEventListener('scroll', checkScrollState);
                window.removeEventListener('resize', checkScrollState);
            };
        }
    }, [checkScrollState, filteredBatches, viewMode]);

    const handleScroll = (direction) => {
        const slider = sliderRef.current;
        if (slider) {
            const scrollDistance = 320 * 2; 
            const newScrollLeft = direction === 'left' 
                ? slider.scrollLeft - scrollDistance 
                : slider.scrollLeft + scrollDistance;
            
            slider.scrollTo({
                left: newScrollLeft,
                behavior: 'smooth'
            });
        }
    };
    

    return (
        <div className="atm_wrapper">
            <h1 className="atm_section-title">Attendance Management Dashboard</h1>
            
            {/* Stage 1: Selection Flow (omitted for brevity, assume correct) */}
            {selectedBatchId === null && (
                <>
                    {/* Step 1: Role Selection */}
                    {userRole !== 'Teacher' &&(
                        <>
                        
                    <h2 className="atm_step-title">Roles</h2>
                    <div className="atm_card-selection-row">
                        {ROLES.map(role => (
                            <NavCard 
                                key={role.id} item={role} selectedId={selectedRole} onSelect={handleRoleSelect} Icon={role.icon} themeClass="selected-pink" 
                            />
                        ))}
                    </div>
                    
                    </>
                    ) }

                    {selectedRole === 'Student' && (
                        <>
                            <h2 className="atm_step-title">Streams (CA or CMA)</h2>
                            <div className="atm_card-selection-row">
                                {STREAMS.map(stream => (
                                    <NavCard key={stream.id} item={stream} selectedId={selectedStream} onSelect={handleStreamSelect} Icon={stream.icon} themeClass="selected-orange" />
                                ))}
                            </div>

                            {selectedStream && (
                                <>
                                    <h2 className="atm_step-title">Courses</h2>
                                    <div className="atm_card-selection-row">
                                        {LEVELS.map(level => (
                                            <NavCard key={level.id} item={level} selectedId={selectedLevel} onSelect={handleLevelSelect} Icon={level.icon} themeClass="selected-gray" />
                                        ))}
                                    </div>
                                </>
                            )}

                            {selectedLevel && (
                                <div className="atm_batch-container">
                                    <h2 className="atm_step-title">Batches ({filteredBatches.length} Found)</h2>
                                    <div className="am_search-bar">
                                        <Search className="am_search-icon" size={18} />
                                        <input
                                            type="text"
                                            className="am_search-input"
                                            placeholder="Search by Batch Name or Code (e.g., Apr 2025 or CAF-)"
                                            value={searchTerm}
                                            onChange={(e) => setSearchTerm(e.target.value)}
                                        />
                                    </div>

                                    {filteredBatches.length > 0 ? (
                                        <div className="atm_batch-slider-outer">
                                            {showControls && (
                                                <>
                                                    <div className={`atm_slider-button left ${!canScrollLeft ? 'disabled' : ''}`} onClick={() => canScrollLeft && handleScroll('left')} aria-label="Scroll left"><ChevronLeft size={20} /></div>
                                                    <div className={`atm_slider-button right ${!canScrollRight ? 'disabled' : ''}`} onClick={() => canScrollRight && handleScroll('right')} aria-label="Scroll right"><ChevronRight size={20} /></div>
                                                </>
                                            )}
                                            <div className="atm_batch-slider-wrapper" ref={sliderRef}>
                                                <div className="atm_batch-slider-content">
                                                    {filteredBatches.map(batch => (
                                                        <BatchCard key={batch.id} batch={batch} isSelected={batch.id === selectedBatchId} onSelect={handleBatchSelect} />
                                                    ))}
                                                </div>
                                            </div>
                                        </div>
                                    ) : (
                                        <div className="atm_empty-message">No batches found matching your selected criteria.</div>
                                    )}
                                </div>
                            )}
                        </>
                    )}
                    {(selectedRole === 'Teacher' || selectedRole === 'Admin') && (
                        <div className="atm_info-block atm_teacher-admin">
                            The flow for <strong>{selectedRole}</strong> is currently not implemented. Please select <strong>Student</strong> to continue the demonstration.
                        </div>
                    )}
                </>
            )}

            {/* Stage 2: Attendance Marking Table */}
            {selectedBatchId !== null && (
                <div className="atm_attendance-dashboard">
                    <div className="atm_dashboard-header">
                        <h2 className="atm_dashboard-title">
                            Attendance: {DUMMY_BATCHES.find(b => b.id === selectedBatchId)?.courseName}
                        </h2>
                        {userRole !== 'Teacher' &&              
                        (          <button className="atm_back-button" onClick={() => setSelectedBatchId(null)}>
                            <ChevronLeft size={16} /> Change Batch
                        </button>
                    )}
                    </div>

                    {/* UPDATED: Filter/Search Bar with new look and Excel button */}
                    <div className="atm_filter-bar-new">
                        <div className="am_search-bar">
                            <Search className="am_search-icon" size={20} />
                            <input
                                type="text"
                                className="am_search-input"
                                placeholder="Filter by Student Name or Roll No"
                                value={searchTermStudents}
                                onChange={(e) => setSearchTermStudents(e.target.value)}
                            />
                        </div>
                        
                        <div className="atm_filter-actions-group">
                            {/* UPDATED: Custom Dropdown for Gender Filter */}
                            <CustomDropdown
                                options={GENDER_OPTIONS}
                                value={genderFilter}
                                onChange={setGenderFilter}
                                placeholder="Select Gender"
                                icon={Filter}
                            />
                            
                            {/* NEW: Export to Excel Button */}
                            <button className="atm_export-excel-button" onClick={handleExportExcel}>
                                <FileDown size={18} /> Export to Excel
                            </button>
                        </div>
                    </div>

                    {/* Stats Cards (omitted for brevity, assume correct) */}
                    <div className="atm_stats-row">
                        <StatsCard title="Total Students" value={stats.total} icon={Users} colorClass="atm_stats-total" />
                        <StatsCard title="Filtered Students" value={stats.filteredCount} icon={Filter} colorClass="atm_stats-filtered" />
                        <StatsCard title="Present Today" value={stats.presentToday} icon={Check} colorClass="atm_stats-present" />
                        <StatsCard title="Absent Today" value={stats.absentToday} icon={X} colorClass="atm_stats-absent" />
                    </div>

                    {/* Attendance Table */}
                    <AttendanceTable 
                        students={filteredStudents}
                        attendanceData={attendanceData}
                        days={days} // Dynamic dates array
                        toggleAttendance={toggleAttendance}
                        viewMode={viewMode}
                        toggleViewMode={toggleViewMode}
                    />
                </div>
            )}
        </div>
    );
};

export default AttendanceManagement;