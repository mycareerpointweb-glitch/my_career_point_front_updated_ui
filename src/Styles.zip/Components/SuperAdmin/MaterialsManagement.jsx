import React, { useState, useEffect, useRef } from "react";
import { 
    FiSearch, FiX, FiPlus, FiChevronLeft, FiChevronRight, 
    FiCheckCircle, FiBookOpen, FiTrash2, 
    FiEdit2, FiFileText, FiFile, FiImage, FiList, FiGrid, 
    FiAlertTriangle 
} from "react-icons/fi"; 
import "../../Styles/SuperAdmin/MaterialsManagement.css"; 
// import { get } from "../../../../backend/routes/auth";

// --- Mock Data (Extended with Documents) ---
const mockData = {
    streams: [
        { id: 'ca', name: 'Chartered Accountancy (CA)', icon: FiBookOpen },
        { id: 'cma', name: 'Cost and Management Accountancy (CMA)', icon: FiBookOpen },
    ],
    levels: {
        ca: [
            { id: 'ca-f', name: 'Foundation', description: 'Core basic principles and entry knowledge.', streamId: 'ca' },
            { id: 'ca-i', name: 'Intermediate', description: 'Advanced concepts and practical application.', streamId: 'ca' },
            { id: 'ca-a', name: 'Advanced', description: 'Final concepts and expert-level syllabus.', streamId: 'ca' },
        ],
        cma: [
            { id: 'cma-f', name: 'Foundation', description: 'Basic management accounting principles.', streamId: 'cma' },
            { id: 'cma-i', name: 'Intermediate', description: 'Costing, financial management, and law.', streamId: 'cma' },
            { id: 'cma-a', name: 'Advanced', description: 'Corporate strategy and financial reporting.', streamId: 'cma' },
        ],
    },
    subjects: [
        { id: 1, code: 'CA-F01', name: 'Principles of Accounting', streamId: 'ca', levelId: 'ca-f' },
        { id: 2, code: 'CA-F02', name: 'Business Law', streamId: 'ca', levelId: 'ca-f' },
        { id: 3, code: 'CA-I03', name: 'Taxation', streamId: 'ca', levelId: 'ca-i' },
        { id: 4, code: 'CA-I04', name: 'Corporate Finance', streamId: 'ca', levelId: 'ca-i' },
        { id: 5, code: 'CA-I03', name: 'Taxation', streamId: 'ca', levelId: 'ca-i' },
        { id: 6, code: 'CA-I04', name: 'Corporate Finance', streamId: 'ca', levelId: 'ca-i' },
        { id: 7, code: 'CA-I03', name: 'Taxation', streamId: 'ca', levelId: 'ca-i' },
        { id: 8, code: 'CA-I04', name: 'Corporate Finance', streamId: 'ca', levelId: 'ca-i' },
        { id: 9, code: 'CA-A05', name: 'Auditing and Assurance', streamId: 'ca', levelId: 'ca-a' },
        { id: 10, code: 'CMA-F01', name: 'Fundamentals of Costing', streamId: 'cma', levelId: 'cma-f' },
        { id: 11, code: 'CMA-I03', name: 'Operations Management', streamId: 'cma', levelId: 'cma-i' },
        { id: 12, code: 'CMA-A05', name: 'Strategic Management', streamId: 'cma', levelId: 'cma-a' },
    ],
    // Mock Documents associated with multiple Subject IDs
    documents: [
        // --- Subject ID 3 (Taxation) - Existing Data ---
        { id: 101, subjectId: 3, name: 'Income Tax Chapter 1 Summary', type: 'pdf', size: '5.2 MB', uploaded: '2025-09-01' },
        { id: 102, subjectId: 3, name: 'GST Calculation Examples', type: 'docx', size: '1.1 MB', uploaded: '2025-09-05' },
        { id: 103, subjectId: 3, name: 'Audit Standards Presentation', type: 'pptx', size: '15.8 MB', uploaded: '2025-09-10' },
        { id: 104, subjectId: 3, name: 'Important Definitions', type: 'txt', size: '0.1 MB', uploaded: '2025-09-15' },
        { id: 105, subjectId: 3, name: 'Tax Slab Chart', type: 'jpg', size: '0.8 MB', uploaded: '2025-09-20' },
        
        // --- Subject ID 4 (Corporate Finance) - New Data ---
        { id: 106, subjectId: 4, name: 'Equity Valuation Model', type: 'xlsx', size: '2.4 MB', uploaded: '2025-10-01' }, 
        { id: 107, subjectId: 4, name: 'Capital Budgeting Case Study', type: 'pdf', size: '8.9 MB', uploaded: '2025-10-05' },
        { id: 108, subjectId: 4, name: 'WACC Formulas Reference', type: 'txt', size: '0.2 MB', uploaded: '2025-10-08' },
        { id: 109, subjectId: 4, name: 'Merger and Acquisition Policy', type: 'docx', size: '4.5 MB', uploaded: '2025-10-12' },

        // --- Subject ID 5 (Auditing and Assurance) - New Data ---
        { id: 110, subjectId: 5, name: 'SA 700 Summary Notes', type: 'pdf', size: '3.1 MB', uploaded: '2025-11-01' },
        { id: 111, subjectId: 5, name: 'Risk Assessment Checklist', type: 'xlsx', size: '0.5 MB', uploaded: '2025-11-05' },
        { id: 112, subjectId: 5, name: 'Audit Report Template', type: 'docx', size: '1.9 MB', uploaded: '2025-11-10' },
        { id: 113, subjectId: 5, name: 'Sample Vouching Records', type: 'jpg', size: '1.2 MB', uploaded: '2025-11-15' },

        // --- Subject ID 6 (Fundamentals of Costing) - New Data ---
        { id: 114, subjectId: 6, name: 'Material Costing Chapter', type: 'pdf', size: '6.4 MB', uploaded: '2025-12-01' },
        { id: 115, subjectId: 6, name: 'Labour Hour Calculations', type: 'xlsx', size: '0.9 MB', uploaded: '2025-12-05' },
        { id: 116, subjectId: 6, name: 'Overhead Allocation PPT', type: 'pptx', size: '12.3 MB', uploaded: '2025-12-10' },
    ]
};

// --- Helper function to get the correct icon (Using available Feather Icons) ---
const getFileIcon = (type) => {
    switch (type.toLowerCase()) {
        case 'jpg':
        case 'png':
        case 'jpeg': 
            return FiImage;
        case 'pdf': 
        case 'docx':
        case 'doc': 
        case 'pptx':
        case 'ppt': 
        case 'txt': 
        case 'xlsx': 
            return FiFileText;
        default: 
            return FiFile;
    }
};

// --- New Component for Confirmation Modal ---
const ConfirmationModal = ({ isOpen, title, message, onConfirm, onCancel }) => {
    if (!isOpen) return null;

    return (
        <div className="mm_model-overlay active">
            <div className="mm_confirm-modal-content">
                <div className="mm_confirm-modal-header">
                    <h2>{title}</h2>
                    <button className="mm_model-close-btn" onClick={onCancel}>
                        <FiX />
                    </button>
                </div>
                <div className="mm_confirm-modal-body">
                    <FiAlertTriangle size={36} className="mm_confirm-icon" />
                    <p>{message}</p>
                </div>
                <div className="mm_modal-actions">
                    <button type="button" className="mm_btn-outline" onClick={onCancel}>
                        Cancel
                    </button>
                    <button type="button" className="mm_btn-danger" onClick={onConfirm}>
                        <FiTrash2 /> Delete
                    </button>
                </div>
            </div>
        </div>
    );
};


// --- Sub-Component for Slider ---
const SubjectSlider = ({ subjects, selectedSubject, onSelect }) => {
    const sliderRef = useRef(null);
    const [showLeftControl, setShowLeftControl] = useState(false);
    const [showRightControl, setShowRightControl] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');

    const filteredSubjects = subjects.filter(subject => 
        subject.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        subject.code.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const checkScroll = () => {
        if (sliderRef.current) {
            const { scrollLeft, scrollWidth, clientWidth } = sliderRef.current;
            setShowLeftControl(scrollLeft > 0);
            setShowRightControl(scrollWidth > clientWidth && scrollLeft < scrollWidth - clientWidth - 5); // 5px buffer
        }
    };

    const scroll = (direction) => {
        if (sliderRef.current) {
            const scrollAmount = sliderRef.current.clientWidth * 0.7; // Scroll 70% of the visible area
            sliderRef.current.scrollBy({
                left: direction === 'left' ? -scrollAmount : scrollAmount,
                behavior: 'smooth'
            });
        }
    };

    useEffect(() => {
        checkScroll();
        const slider = sliderRef.current;
        if (slider) {
            slider.addEventListener('scroll', checkScroll);
        }
        window.addEventListener('resize', checkScroll);
        return () => {
             if (slider) {
                slider.removeEventListener('scroll', checkScroll);
            }
            window.removeEventListener('resize', checkScroll);
        };
    }, [subjects]); 

    return (
        <div className="mm_subject-selection-container">
            <div className="mm_section-header-flex mm_bottom-border-section">
                <h2 className="mm_section-title-no-border">Subject</h2>
                <div className="mm_subject-search-bar mm_search-bar">
                    <FiSearch className="mm_search-icon" />
                    <input
                        type="text"
                        placeholder="Search Subject Name or Code..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                    {searchTerm && <FiX className="mm_clear-icon" onClick={() => setSearchTerm('')} />}
                </div>
            </div>

            <div className="mm_slider-wrapper">
                {showLeftControl && (
                    <div className="mm_slider-control left" onClick={() => scroll('left')}>
                        <FiChevronLeft size={20} />
                    </div>
                )}
                
                <div className="mm_slider-content" ref={sliderRef}>
                    {filteredSubjects.length > 0 ? (
                        filteredSubjects.map(subject => (
                            <div 
                                key={subject.id} 
                                className={`mm_subject-card ${selectedSubject && selectedSubject.id === subject.id ? `selcted`: ''}`}
                                onClick={() => onSelect(subject)}
                            >
                                <p className="mm_subject-code">{subject.code}</p>
                                <h4>{subject.name}</h4>
                                {selectedSubject && selectedSubject.id === subject.id && 
                                    <FiCheckCircle size={20} className={`${selectedSubject && selectedSubject.id === subject.id ? `selcted`: ''}`} style={{marginTop: '10px'}} />
                                }
                            </div>
                        ))
                    ) : (
                        <div className="mm_no-results">No subjects found matching "{searchTerm}".</div>
                    )}
                </div>

                {showRightControl && (
                    <div className="mm_slider-control right" onClick={() => scroll('right')}>
                        <FiChevronRight size={20} />
                    </div>
                )}
            </div>
        </div>
    );
};

// --- Sub-Component for Matrix/Explore View (Grid of Cards) ---
const ExploreMaterialView = ({ materials, handleSelectMaterial, selectedMaterials, handleDelete, handleRenameStart, isRenaming, newName, setNewName, handleRenameSubmit }) => {
    return (
        <div className="mm_explore-grid">
            {materials.map(material => {
                const FileIcon = getFileIcon(material.type);
                const isCurrentRenaming = isRenaming === material.id;
                
                return (
                    // Added file-type class for card color hints on hover/selection
                    <div 
                        key={material.id} 
                        className={`mm_material-card mm_file-type-${material.type.toLowerCase()} ${selectedMaterials.has(material.id) ? 'mm_selected-card' : ''}`}
                        onClick={(e) => {
                            // Prevent card selection if the click target is an action button or rename input
                            if (!e.target.closest('.mm_card-actions-top') && !e.target.closest('.mm_rename-input-card')) {
                                handleSelectMaterial(material.id);
                            }
                        }}
                    >
                        
                        <div className="mm_card-header">
                            {/* Custom Checkbox Implementation */}
                            <label className="mm_custom-checkbox">
                                <input 
                                    type="checkbox" 
                                    checked={selectedMaterials.has(material.id)}
                                    onChange={() => handleSelectMaterial(material.id)}
                                />
                                <span className="mm_checkmark"></span>
                            </label>

                            <div className="mm_card-actions-top"> 
                                {isCurrentRenaming ? (
                                    <button 
                                        className="mm_action-btn mm_action-save" 
                                        onClick={(e) => { e.stopPropagation(); handleRenameSubmit(material.id); }}
                                        title="Save Rename"
                                    >
                                        <FiCheckCircle size={18} />
                                    </button>
                                ) : (
                                    <button 
                                        className="mm_action-btn mm_action-edit" 
                                        onClick={(e) => { e.stopPropagation(); handleRenameStart(material); }}
                                        title="Rename File"
                                    >
                                        <FiEdit2 size={15} />
                                    </button>
                                )}
                                <button 
                                    className="mm_action-btn mm_action-delete" 
                                    // Use the passed-in handleDelete (which is triggerSingleDelete)
                                    onClick={(e) => { e.stopPropagation(); handleDelete(material.id); }}
                                    title="Delete File"
                                >
                                    <FiTrash2 size={15} />
                                </button>
                            </div>
                        </div>

                        <div className="mm_card-icon-main-container">
                             <FileIcon size={48} className={`mm_file-icon mm_file-icon-main mm_file-icon-${material.type.toLowerCase()}`} />
                            <span className="mm_card-type-tag">{material.type.toUpperCase()}</span>
                        </div>

                        <div className="mm_card-body-grid">
                            {isCurrentRenaming ? (
                                <>
                                    <input
                                        type="text"
                                        className="mm_rename-input-card"
                                        value={newName}
                                        onChange={(e) => setNewName(e.target.value)}
                                        onBlur={() => handleRenameSubmit(material.id)}
                                        onKeyDown={(e) => {
                                            if (e.key === 'Enter') handleRenameSubmit(material.id);
                                            if (e.key === 'Escape') setIsRenaming(null);
                                        }}
                                        onClick={(e) => e.stopPropagation()} // Stop propagation on input click
                                        autoFocus
                                    />
                                    <span className="mm_file-extension-card">.{material.type}</span>
                                </>
                            ) : (
                                <span className="mm_card-filename" title={`${material.name}.${material.type}`}>{material.name}.{material.type}</span>
                            )}
                            <div className="mm_card-details">
                                <span className="mm_detail-item"><strong>{material.size}</strong></span>
                                <span className="mm_detail-item">Uploaded: {material.uploaded}</span>
                            </div>
                        </div>
                    </div>
                );
            })}
        </div>
    );
};


// --- Sub-Component for Document Listing (Controller) ---
const SubjectMaterialList = ({ subject }) => {
    const [materials, setMaterials] = useState(mockData.documents.filter(doc => doc.subjectId === subject.id));
    const [selectedMaterials, setSelectedMaterials] = useState(new Set());
    const [isRenaming, setIsRenaming] = useState(null); // id of the file being renamed
    const [newName, setNewName] = useState('');
    const [viewMode, setViewMode] = useState('table'); // Changed default to 'table'

    // Confirmation Modal States
    const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
    const [deleteCandidateId, setDeleteCandidateId] = useState(null);
    const [isBulkDelete, setIsBulkDelete] = useState(false);

    const getMaterialById = (id) => materials.find(m => m.id === id);

    const handleSelectAll = (e) => {
        if (e.target.checked) {
            const allIds = materials.map(m => m.id);
            setSelectedMaterials(new Set(allIds));
        } else {
            setSelectedMaterials(new Set());
        }
    };

    const handleSelectMaterial = (id) => {
        setSelectedMaterials(prev => {
            const newSet = new Set(prev);
            if (newSet.has(id)) {
                newSet.delete(id);
            } else {
                newSet.add(id);
            }
            return newSet;
        });
    };

    // New Delete Logic: Single File (triggers modal)
    const triggerSingleDelete = (id) => {
        setDeleteCandidateId(id);
        setIsBulkDelete(false);
        setIsConfirmModalOpen(true);
    };

    // New Delete Logic: Bulk Delete (triggers modal)
    const triggerBulkDelete = () => {
        if (selectedMaterials.size === 0) return;
        setDeleteCandidateId(null);
        setIsBulkDelete(true);
        setIsConfirmModalOpen(true);
    };

    // Logic executed on modal confirmation
    const confirmDelete = () => {
        if (isBulkDelete) {
            setMaterials(prev => prev.filter(m => !selectedMaterials.has(m.id)));
            setSelectedMaterials(new Set());
            // alert(`${selectedMaterials.size} files deleted successfully.`); // Keeping alerts out of final code
        } else if (deleteCandidateId) {
            setMaterials(prev => prev.filter(m => m.id !== deleteCandidateId));
            setSelectedMaterials(prev => {
                const newSet = new Set(prev);
                newSet.delete(deleteCandidateId);
                return newSet;
            });
            // alert("File deleted successfully.");
        }
        closeConfirmModal();
    };

    const closeConfirmModal = () => {
        setIsConfirmModalOpen(false);
        setDeleteCandidateId(null);
        setIsBulkDelete(false);
    };

    const handleRenameStart = (material) => {
        const fileName = material.name;
        setIsRenaming(material.id);
        setNewName(fileName);
    };

    const handleRenameSubmit = (id) => {
        if (newName.trim() === "") {
             // alert("File name cannot be empty.");
             return;
        }
        
        setMaterials(prev => prev.map(m => 
            m.id === id ? { ...m, name: newName.trim() } : m
        ));
        setIsRenaming(null);
        setNewName('');
    };
    
    const isAllSelected = selectedMaterials.size > 0 && selectedMaterials.size === materials.length;
    const isIndeterminate = selectedMaterials.size > 0 && selectedMaterials.size < materials.length;
    
    // Create the pills list
    const selectedMaterialPills = Array.from(selectedMaterials)
        .map(id => getMaterialById(id))
        .filter(m => m !== undefined); 

    return (
        <div className="mm_material-list-container">
            {/* The mm_section-header-flex container ensures the title and the group below are on the same line */}
            <div className="mm_section-header-flex">
                 <h2 className="mm_section-title-no-border">Materials for: {subject.code} - {subject.name}</h2>
                 
                 {/* Grouping the 'Add Materials' button and the 'View Toggle' together for clean alignment */}
                 <div style={{ display: 'flex', alignItems: 'center', gap: '15px', flexWrap: 'wrap' }}> 
                    <button 
                        className="mm_btn-primary"
                        onClick={() => alert(`Open Upload Modal for: ${subject.code}`)}
                    >
                        <FiPlus /> Add Materials
                    </button>

                    <div className="mm_view-toggle">
                        <button 
                            className={`mm_view-btn ${viewMode === 'table' ? 'mm_active' : ''}`}
                            onClick={() => setViewMode('table')}
                            title="Table View"
                        >
                            <FiList size={20} /> Table View
                        </button>
                        <button 
                            className={`mm_view-btn ${viewMode === 'explore' ? 'mm_active' : ''}`}
                            onClick={() => setViewMode('explore')}
                            title="Matrix View (File Explorer)"
                        >
                            <FiGrid size={20} /> Explorer View
                        </button>
                    </div>
                 </div>
            </div>

            {/* Selection Pills Display */}
            {selectedMaterialPills.length > 0 && (
                <div className="mm_selection-pills-container">
                    <span className="mm_pills-label">Selected Files ({selectedMaterialPills.length}):</span>
                    {selectedMaterialPills.map(material => (
                        <div key={material.id} className="mm_selection-pill">
                            <span title={`${material.name}.${material.type}`}>{material.name}.{material.type.toLowerCase()}</span>
                            <FiX size={14} className="mm_pill-cancel" onClick={() => handleSelectMaterial(material.id)} />
                        </div>
                    ))}
                </div>
            )}
            
            {materials.length === 0 ? (
                <div className="mm_empty-state">
                    <p>No materials have been uploaded for this subject yet.</p>
                    <button className="mm_btn-primary" style={{marginTop: '15px'}} onClick={() => alert("Open Upload Modal")}>
                        <FiPlus/> Upload First Material
                    </button>
                </div>
            ) : viewMode === 'table' ? (
                // --- TABLE VIEW ---
                // ADDED RESPONSIVE CONTAINER HERE
                <div className="mm_table-responsive-container"> 
                    <table className="mm_material-table">
                        <thead>
                            <tr>
                                <th className="mm_checkbox-col">
                                    <label className="mm_custom-checkbox">
                                        <input 
                                            type="checkbox" 
                                            checked={isAllSelected}
                                            onChange={handleSelectAll}
                                            ref={el => el && (el.indeterminate = isIndeterminate)}
                                        />
                                        <span className="mm_checkmark"></span>
                                    </label>
                                </th>
                                <th>File Name</th>
                                <th className="mm_size-col">Size</th>
                                <th className="mm_date-col">Uploaded</th>
                                <th className="mm_actions-col">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {materials.map(material => {
                                const FileIcon = getFileIcon(material.type);
                                const isCurrentRenaming = isRenaming === material.id;
                                
                                return (
                                    <tr key={material.id} className={selectedMaterials.has(material.id) ? 'mm_selected-row' : ''}>
                                        <td className="mm_checkbox-col">
                                            {/* Custom Checkbox for Individual Selection */}
                                            <label className="mm_custom-checkbox">
                                                <input 
                                                    type="checkbox" 
                                                    checked={selectedMaterials.has(material.id)}
                                                    onChange={() => handleSelectMaterial(material.id)}
                                                />
                                                <span className="mm_checkmark"></span>
                                            </label>
                                        </td>
                                        <td className="mm_filename-col">
                                            <FileIcon size={20} className={`mm_file-icon mm_file-icon-${material.type.toLowerCase()}`} />
                                            
                                            {isCurrentRenaming ? (
                                                <>
                                                    <input
                                                        type="text"
                                                        className="mm_rename-input"
                                                        value={newName}
                                                        onChange={(e) => setNewName(e.target.value)}
                                                        onBlur={() => handleRenameSubmit(material.id)}
                                                        onKeyDown={(e) => {
                                                            if (e.key === 'Enter') handleRenameSubmit(material.id);
                                                            if (e.key === 'Escape') setIsRenaming(null);
                                                        }}
                                                        autoFocus
                                                    />
                                                    <span className="mm_file-extension">.{material.type}</span>
                                                </>
                                            ) : (
                                                <span>{material.name}.{material.type}</span>
                                            )}
                                        </td>
                                        <td className="mm_size-col">{material.size}</td>
                                        <td className="mm_date-col">{material.uploaded}</td>
                                        <td className="mm_actions-col">
                                            <div className="mm_table-actions-group">
                                                {isCurrentRenaming ? (
                                                    <button 
                                                        className="mm_action-btn mm_action-save" 
                                                        onClick={() => handleRenameSubmit(material.id)}
                                                        title="Save Rename"
                                                    >
                                                        <FiCheckCircle size={18} />
                                                    </button>
                                                ) : (
                                                    <button 
                                                        className="mm_action-btn mm_action-edit" 
                                                        onClick={() => handleRenameStart(material)}
                                                        title="Rename File"
                                                    >
                                                        <FiEdit2 size={18} />
                                                    </button>
                                                )}
                                                <button 
                                                    className="mm_action-btn mm_action-delete" 
                                                    onClick={() => triggerSingleDelete(material.id)} // Use modal trigger
                                                    title="Delete File"
                                                >
                                                    <FiTrash2 size={18} />
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div> // END OF RESPONSIVE CONTAINER
            ) : (
                // --- EXPLORE VIEW (MATRIX) ---
                <ExploreMaterialView 
                    materials={materials} 
                    handleSelectMaterial={handleSelectMaterial} 
                    selectedMaterials={selectedMaterials} 
                    handleDelete={triggerSingleDelete} // Pass the modal trigger function
                    handleRenameStart={handleRenameStart} 
                    isRenaming={isRenaming} 
                    newName={newName} 
                    setNewName={setNewName} 
                    handleRenameSubmit={handleRenameSubmit} 
                />
            )}
            
            {selectedMaterials.size > 0 && (
                <div className="mm_bulk-actions">
                    <span>{selectedMaterials.size} files selected:</span>
                    <button className="mm_btn-outline mm_btn-small mm_btn-danger-outline" onClick={triggerBulkDelete}>
                        <FiTrash2 size={14} /> Bulk Delete
                    </button>
                </div>
            )}

            {/* Confirmation Modal */}
            <ConfirmationModal 
                isOpen={isConfirmModalOpen}
                title={isBulkDelete ? `Confirm Bulk Delete` : `Confirm Delete: ${deleteCandidateId ? getMaterialById(deleteCandidateId)?.name : ''}`}
                message={isBulkDelete 
                    ? `Are you sure you want to permanently delete ${selectedMaterials.size} files? This action cannot be undone.`
                    : `Are you sure you want to permanently delete the file "${deleteCandidateId ? getMaterialById(deleteCandidateId)?.name : ''}"?`
                }
                onConfirm={confirmDelete}
                onCancel={closeConfirmModal}
            />
        </div>
    );
};

// --- Main Component ---
const MaterialManagement = ({userRole}) => {
    const initialStream = mockData.streams.find(s => s.id === 'ca'); // Chartered Accountancy (CA)
    const initialLevels = mockData.levels['ca'];
    const initialLevel = initialLevels ? initialLevels.find(l => l.id === 'ca-i') : null; // Intermediate
    const initialSubjects = mockData.subjects.filter(
        s => s.streamId === 'ca' && s.levelId === 'ca-i'
    );
    const initialSubject = initialSubjects.find(s => s.id === 3);


    const [selectedStream, setSelectedStream] = useState(initialStream);
    const [selectedLevel, setSelectedLevel] = useState(initialLevel);
    const [selectedSubject, setSelectedSubject] = useState(initialSubject);
    const [filteredLevels, setFilteredLevels] = useState(initialLevels || []);
    const [filteredSubjects, setFilteredSubjects] = useState(initialSubjects || []);
    const [isAddStreamOpen, setAddStreamOpen] = useState(false);
    const [newStreamForm, setNewStreamForm] = useState({ name: '', icon: '' });
    
    // NEW: Ref for auto-scrolling to the Material List
    const materialListRef = useRef(null); 
    
    // NEW: Effect to scroll to the material list when a subject is selected
    useEffect(() => {
        if (selectedSubject && materialListRef.current) {
            // Scroll to the start/center of the new section
            materialListRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, [selectedSubject]);


    // --- Step 1: Handle Stream Selection ---
    const handleStreamSelect = (stream) => {
        console.log(stream);
        if (selectedStream && selectedStream.id === stream.id) {
            setSelectedStream(null);
            setSelectedLevel(null);
            setSelectedSubject(null);
            setFilteredLevels([]);
            setFilteredSubjects([]);
        } else {
            setSelectedStream(stream);
            setSelectedLevel(null);
            setSelectedSubject(null);
            setFilteredLevels(mockData.levels[stream.id] || []);
            setFilteredSubjects([]);
        }
    };

    // --- Step 2: Handle Level Selection ---
    const handleLevelSelect = (level) => {
        console.log(level)
        if (selectedLevel && selectedLevel.id === level.id) {
            setSelectedLevel(null);
            setSelectedSubject(null);
            setFilteredSubjects([]);
        } else {
            setSelectedLevel(level);
            setSelectedSubject(null);
            const subjects = mockData.subjects.filter(
                s => s.streamId === level.streamId && s.levelId === level.id
            );
            setFilteredSubjects(subjects);
        }
    };

    // --- Step 3: Handle Subject Selection ---
    const handleSubjectSelect = (subject) => {
        console.log(subject)
        if (selectedSubject && selectedSubject.id === subject.id) {
            setSelectedSubject(null);
        } else {
            setSelectedSubject(subject);
        }
    };

    // --- Form for Adding New Stream (Mocked) ---
    const handleNewStreamSubmit = (e) => {
        e.preventDefault();
        console.log("Adding new stream:", newStreamForm);
        setAddStreamOpen(false);
        setNewStreamForm({ name: '', icon: '' });
    };

    // --- JSX for Component ---
    return (
        <div className="mm_wrapper">
            <div className="mm_header">
                <h1 className="mm_page-title">Material & Subject Management</h1>
               
            </div>
{ userRole !== 'Teacher' && (
    <>
            <h2 className="mm_section-title">Stream</h2>
            <div className="mm_stream-nav-flex">
                {mockData.streams.map(stream => {
                    const StreamIcon = stream.icon;
                    const isSelected = selectedStream && selectedStream.id === stream.id;
                    const selectedClass = isSelected ? `selected-${stream.id}` : '';
                    
                    return (
                        <div 
                            key={stream.id}
                            className={`mm_stream-pill ${selectedClass}`}
                            onClick={() => handleStreamSelect(stream)}
                        >
                            <StreamIcon size={20} />
                            {stream.name}
                            {isSelected && <FiCheckCircle size={18} />}
                        </div>
                    );
                })}
            </div>
            </>
            )}
            {selectedStream && userRole !== 'Teacher' &&  (
                <>
                    <h2 className="mm_section-title">Courses({selectedStream.name})</h2>
                    <div className="mm_level-grid">
                        {filteredLevels.map(level => {
                            const isSelected = selectedLevel && selectedLevel.id === level.id;
                            const selectedClass = isSelected ? `selected-level-${selectedStream.id}` : '';

                            return (
                                <div 
                                    key={level.id}
                                    className={`mm_level-card ${selectedClass}`}
                                    onClick={() => handleLevelSelect(level)}
                                >
                                    <div className="mm_level-card-header">
                                        <h3>{level.name}</h3>
                                        {isSelected && <FiCheckCircle size={20} color={`var(--brand-${selectedStream.id === 'ca' ? 'pink' : 'orange'})`} />}
                                    </div>
                                    <p>{level.description}</p>
                                </div>
                            );
                        })}
                    </div>
                </>
            )}

            {/* ==================================== */}
            {/* STEP 3: Select Subject (Searchable Slider) */}
            {/* ==================================== */}
            {selectedLevel && userRole !== 'Teacher' &&(
                <SubjectSlider 
                    subjects={filteredSubjects} 
                    selectedSubject={selectedSubject} 
                    onSelect={handleSubjectSelect} 
                />
            )}
            {selectedSubject && (
                <div ref={materialListRef} className="mm_material-list-section">
                    <SubjectMaterialList subject={selectedSubject} />
                </div>
            )}
        </div>
    );
};

export default MaterialManagement;