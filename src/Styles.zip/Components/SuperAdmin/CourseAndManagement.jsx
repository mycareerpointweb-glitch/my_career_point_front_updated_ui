import React, { useState, useEffect, useRef } from "react";
import { FiSearch, FiX, FiEdit2, FiPlus, FiTrash2, FiAlertTriangle, FiCheckCircle, FiBookOpen, FiChevronDown } from "react-icons/fi";
import "../../Styles/SuperAdmin/CourseAndManagement.css"; // Contains all cm_ prefixed styles

// --- SearchableDropdown Component (NEW) ---
const SearchableDropdown = ({ options, selectedValues, onToggle, label }) => {
    const [searchTerm, setSearchTerm] = useState("");
    const [isOpen, setIsOpen] = useState(false);
    const dropdownRef = useRef(null);

    // Filter options based on search term
    const filteredOptions = options.filter(option =>
        option.label.toLowerCase().includes(searchTerm.toLowerCase())
    );

    // Close dropdown on outside click
    useEffect(() => {
        const handleClickOutside = (event) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                setIsOpen(false);
                setSearchTerm(""); // Clear search when closing
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, []);

    // Get the labels of the currently selected teachers to display as pills
    const selectedLabels = selectedValues.map(value => {
        const option = options.find(o => o.value === value);
        return option ? option.label : '';
    });
    
    // Toggle dropdown open/close
    const handleToggleDropdown = (e) => {
        e.preventDefault(); // Prevent form submission if inside a form
        setIsOpen(prev => !prev);
    };

    return (
        <div className="cm_searchable-dropdown" ref={dropdownRef}>
            <label>{label}</label>
            <div className="cm_dropdown-header" onClick={handleToggleDropdown}>
                {selectedLabels.length > 0 ? (
                    <div className="cm_pills-container">
                        {selectedLabels.map(label => (
                            <span key={label} className="cm_teacher-pill">{label}</span>
                        ))}
                    </div>
                ) : (
                    <span className="cm_placeholder-text">Select one or more instructors...</span>
                )}
                <FiChevronDown className={`cm_dropdown-icon ${isOpen ? 'open' : ''}`} />
            </div>

            {isOpen && (
                <div className="cm_dropdown-content">
                    <div className="cm_dropdown-search">
                        <FiSearch className="cm_search-icon" />
                        <input
                            type="text"
                            placeholder="Search instructors..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            // Autofocus the search input when dropdown opens
                            autoFocus
                            onClick={(e) => e.stopPropagation()} // Keep dropdown open when clicking search input
                        />
                        {searchTerm && (
                            <FiX className="cm_clear-icon" onClick={() => setSearchTerm("")} />
                        )}
                    </div>
                    <div className="cm_checkbox-list">
                        {filteredOptions.length > 0 ? (
                            filteredOptions.map((option) => (
                                <label key={option.value} className="cm_checkbox-label">
                                    <input
                                        type="checkbox"
                                        checked={selectedValues.includes(option.value)}
                                        onChange={() => onToggle(option.value)}
                                    />
                                    {option.label}
                                </label>
                            ))
                        ) : (
                            <p className="cm_no-results">No results found for "{searchTerm}"</p>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
};
// ----------------------------------------------------


const teacherOptions = [
  { value: "teacher1", label: "John Doe" },
  { value: "teacher2", label: "Jane Smith" },
  { value: "teacher3", label: "Mark Lee" },
  { value: "teacher4", label: "Teacher 1" },
  { value: "teacher5", label: "Teacher 2" },
  { value: "teacher6", label: "Teacher 3" },
  { value: "teacher7", label: "Teacher 4" },
  { value: "teacher8", label: "Teacher 5" },
  { value: "teacher9", label: "Teacher 6" },
];

// Replaced original static levelOptions with the initial dynamic state
const initialLevelOptions = ["Foundation", "Intermediate", "Advanced"];

// Constants for navigation
const streams = [
    { name: "CA", label: "Chartered Accountancy" },
    { name: "CMA", label: "Cost & Management Accountancy" },
];

// --- NEW SUBJECT DATA BASED ON USER IMAGE & REQUEST ---
const SUBJECT_DATA = {
    CA: {
        Foundation: [
            { id: 1, subjectName: "Principles & Practice of Accounting", subjectCode: "CA-101", description: "Core subject for CA Foundation", assignedTeachers: ["teacher1", "teacher3"] },
            { id: 2, subjectName: "Business Laws & Business Correspondence", subjectCode: "CA-102", description: "Communication + Law", assignedTeachers: ["teacher2"] },
        ],
        Intermediate: [
            { id: 3, subjectName: "Financial Management & Strategic Management", subjectCode: "CA-302", description: "Advanced level financial and strategic topics.", assignedTeachers: ["teacher1", "teacher3"] },
            // Add more CA Intermediate subjects as needed
        ],
        Advanced: [
            { id: 4, subjectName: "Advanced Auditing and Professional Ethics", subjectCode: "CA-401", description: "In-depth auditing standards.", assignedTeachers: ["teacher4"] },
        ]
    },
    CMA: {
        Foundation: [
            { id: 5, subjectName: "Fundamentals of Economics and Management", subjectCode: "CMA-101", description: "Basic economic principles and business management.", assignedTeachers: ["teacher5"] },
        ],
        Intermediate: [
            { id: 6, subjectName: "Cost Accounting", subjectCode: "CMA-201", description: "Key cost paper", assignedTeachers: ["teacher3", "teacher5"] },
            { id: 7, subjectName: "Taxation – Direct & Indirect", subjectCode: "CMA-303", description: "GST, Direct Tax", assignedTeachers: ["teacher6"] },
            // Add more CMA Intermediate subjects as needed
        ],
        Advanced: [
            { id: 8, subjectName: "Strategic Financial Management", subjectCode: "CMA-401", description: "Advanced financial decision making.", assignedTeachers: ["teacher7"] },
        ]
    }
};
// --------------------------------------------------------


const CourseManagement = () => {
  // Initial state is empty/not selected
  const [selectedStream, setSelectedStream] = useState(""); 
  const [selectedLevel, setSelectedLevel] = useState("");   
    
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState(""); // State used for filtering the table
  const [addCourseOpen, setAddCourseOpen] = useState(false);
  const [editCourse, setEditCourse] = useState(null);

  // === NEW STATE FOR ADD COURSE LEVEL MODAL ===
  const [addLevelOpen, setAddLevelOpen] = useState(false); // State for the new modal
  const [courseLevels, setCourseLevels] = useState(initialLevelOptions); // State to hold current levels
  const [newCourseForm, setNewCourseForm] = useState({ 
    stream: selectedStream || 'CA',
    level: '', // The new level name input, e.g., "Executive"
  });
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  // ===========================================

  // NEW: Refs for auto-scrolling
  const levelNavRef = useRef(null); 
  const subjectTableRef = useRef(null); 

  const addCourseRef = useRef(null);

  const [formData, setFormData] = useState({
    courseName: "",
    subjectCode: "", // Added Subject Code to form data
    description: "",
    // **********************************************
    // REMOVED 'level' from initial formData as it will be set dynamically in handleEdit/Add logic
    // level: initialLevelOptions[0], 
    // **********************************************
    assignedTeachers: [],
  });
  
  // Dummy Assignment Data Structure (This would typically come from an API)
  const [assignmentData, setAssignmentData] = useState({
    courseToInstructor: {
      101: ["teacher1", "teacher3"],
      102: ["teacher2"],
      103: [],
    },
    instructorToCourse: {
      teacher1: [101, 103],
      teacher2: [102],
      teacher3: [101],
    },
  });

  const [assignmentMode, setAssignmentMode] = useState("courseToInstructor");
  const [selectedPrimary, setSelectedPrimary] = useState(null);

  // Sync newCourseForm stream when main selection changes
  useEffect(() => {
    setNewCourseForm(prev => ({
        ...prev,
        stream: selectedStream,
        level: '', // Always clear the new level input when stream changes
    }));
  }, [selectedStream]);

  // Helper to clear feedback messages after a delay
  useEffect(() => {
    if (success || error) {
        const timer = setTimeout(() => {
            setSuccess(null);
            setError(null);
        }, 5000);
        return () => clearTimeout(timer);
    }
  }, [success, error]);


  // Handler to load dummy course data based on selection
  useEffect(() => {
    if (selectedStream && selectedLevel) {
      setLoading(true);
      // Simulate API call delay
      setTimeout(() => {
        // --- UPDATED DUMMY DATA LOADING ---
        const dummyData = SUBJECT_DATA[selectedStream]?.[selectedLevel] || [];
        
        // Map the SUBJECT_DATA structure to the expected 'course' structure
        // The table expects: id, courseName, description, level, assignedTeachers
        const coursesFormatted = dummyData.map(subject => ({
            id: subject.id,
            courseName: subject.subjectName, // Use subjectName as courseName for display
            subjectCode: subject.subjectCode, // Added subjectCode
            description: subject.description,
            level: selectedLevel,
            stream: selectedStream,
            assignedTeachers: subject.assignedTeachers,
        }));
        
        setCourses(coursesFormatted);
        setLoading(false);
      }, 300); 
    } else {
        setCourses([]); // Clear courses if selection is incomplete
        setLoading(false);
    }
  }, [selectedStream, selectedLevel]); 
  
  // NEW: Scroll to the Level Navigation when a Stream is selected
  useEffect(() => {
    if (selectedStream && levelNavRef.current) {
        levelNavRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, [selectedStream]);

  // NEW: Scroll to the Subject Table when a Level is selected
  useEffect(() => {
      if (selectedLevel && subjectTableRef.current) {
          subjectTableRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
  }, [selectedLevel]);


  // Handlers for navigation clicks
  const handleStreamClick = (stream) => {
    setSelectedStream(stream);
    setSelectedLevel(""); // Reset level when stream changes, hiding level cards and course details
    setSearchTerm("");
  };

  const handleLevelClick = (level) => {
    setSelectedLevel(level);
    setSearchTerm("");
  };
  
  // **********************************************
  // New handler for opening the Add Subject modal
  const handleAddSubjectClick = () => {
    if (!selectedStream || !selectedLevel) return; // Should not happen if button is only visible when level is selected
    
    setEditCourse(null); // Ensure we are in "Add" mode
    setFormData({ // Reset form data and set stream/level based on selection
        courseName: "", 
        subjectCode: "",
        description: "", 
        // Set uneditable values for the modal's internal logic
        level: selectedLevel, 
        stream: selectedStream, 
        assignedTeachers: [] 
    });
    setAddCourseOpen(true);
  };
  // **********************************************

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    // Prevent changing stream/level through the form in the modal
    if (name === 'stream' || name === 'level') return; 
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  // **********************************************
  // Updated handler to be passed to SearchableDropdown
  const handleTeacherToggle = (teacherValue) => {
    setFormData((prev) => {
      const isAssigned = prev.assignedTeachers.includes(teacherValue);
      return {
        ...prev,
        assignedTeachers: isAssigned
          ? prev.assignedTeachers.filter((t) => t !== teacherValue)
          : [...prev.assignedTeachers, teacherValue],
      };
    });
  };
  // **********************************************

  const handleSubmit = (e) => {
    e.preventDefault();
    const newCourse = {
      id: editCourse ? editCourse.id : Date.now(),
      // Use the selectedStream and selectedLevel from state as the source of truth
      ...formData, 
      stream: selectedStream, // Ensure correct stream/level from parent component state
      level: selectedLevel,
    };

    if (editCourse) {
      setCourses(courses.map(c => c.id === newCourse.id ? newCourse : c));
      setEditCourse(null);
    } else {
      setCourses([...courses, newCourse]);
    }

    setAddCourseOpen(false);
    // Reset form data
    setFormData({ courseName: "", subjectCode: "", description: "", assignedTeachers: [] });
  };
  
  const handleEdit = (course) => {
    setEditCourse(course);
    setFormData({
      courseName: course.courseName,
      subjectCode: course.subjectCode || "", // Populate subject code for editing
      description: course.description,
      // Include stream/level for display/internal logic, but they are uneditable
      level: course.level, 
      stream: course.stream, 
      assignedTeachers: course.assignedTeachers,
    });
    setAddCourseOpen(true);
  };

  const handleDelete = (id) => {
    // In a real application, you would confirm deletion with the user.
    console.log(`Course with ID ${id} deleted.`);
    setCourses(courses.filter(course => course.id !== id));
  };
  
  const filteredCourses = courses.filter((course) => course.courseName.toLowerCase().includes(searchTerm.toLowerCase()) );

  const handleAssignmentChange = (primaryId, secondaryId) => {
    setAssignmentData((prev) => {
      const newData = { ...prev };
      const primaryKey = assignmentMode === "courseToInstructor" ? "courseToInstructor" : "instructorToCourse";
      const secondaryKey = assignmentMode === "courseToInstructor" ? "instructorToCourse" : "courseToInstructor";
      let assignedList = newData[primaryKey][primaryId] || [];
      const isAssigned = assignedList.includes(secondaryId);

      if (isAssigned) {
        // Remove assignment
        newData[primaryKey][primaryId] = assignedList.filter(id => id !== secondaryId);

        // Remove reciprocal assignment (Optional: for bi-directional sync)
        if (newData[secondaryKey][secondaryId]) {
          newData[secondaryKey][secondaryId] = newData[secondaryKey][secondaryId].filter(id => id !== primaryId);
        }
      } else {
        // Add assignment
        newData[primaryKey][primaryId] = [...assignedList, secondaryId];

        // Add reciprocal assignment (Optional: for bi-directional sync)
        if (!newData[secondaryKey][secondaryId]) {
          newData[secondaryKey][secondaryId] = [];
        }
        newData[secondaryKey][secondaryId].push(primaryId);
      }
      return newData;
    });
  };

  // === HANDLERS FOR ADD COURSE LEVEL MODAL ===
  const handleNewCourseFormChange = (e) => {
    const { name, value } = e.target;
    setNewCourseForm(prev => ({ ...prev, [name]: value }));
  };

  const handleAddNewCourseLevel = (e) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    const newLevelName = newCourseForm.level.trim();

    if (!newLevelName) {
        setError("Course level name cannot be empty.");
        return;
    }

    // Check if level already exists (case-insensitive)
    if (courseLevels.map(l => l.toLowerCase()).includes(newLevelName.toLowerCase())) {
        setError(`The course level "${newLevelName}" already exists.`);
        return;
    }

    // Simulate successful API call and update local state
    setCourseLevels(prevLevels => [...prevLevels, newLevelName]);
    setSelectedLevel(newLevelName); // Automatically select the new level
    setSuccess(`New course level "${newLevelName}" for ${newCourseForm.stream} created successfully!`);
    setAddLevelOpen(false); // Close the modal
    setNewCourseForm({ 
        stream: selectedStream || 'CA', 
        level: '', 
    });
  };

  // ============================================

  return (
    <div className="cm_wrapper">
      <div className="cm_header">
        <h1 className="cm_page-title">Course Management</h1>
        
      </div>

      {/* Stream Navigation Cards */}
      <div className="cm_stream-nav">
        <h3 className="cm_section-title">Select Stream</h3>
        
        {/* NEW WRAPPER TO ALIGN CARDS AND BUTTON */}
        <div className="cm_stream-nav-container">
            <div className="cm_stream-nav-flex">
                {streams.map((stream) => (
                    <div
                        key={stream.name}
                        className={`cm_nav-card ${selectedStream === stream.name ? "selected" : ""}`}
                        onClick={() => handleStreamClick(stream.name)}
                    >
                      <FiBookOpen size={28} />
                        <h3>{stream.name}</h3>
                        <p>{stream.label}</p>
                    </div>
                ))}
            </div>
            
            
            {/* BUTTON ADDED TO THE RIGHT CORNER */}
        </div>
            
      
      </div>
      {/* **********************************************
        REMOVED THE FLOATING 'Add Subject' BUTTON HERE
        **********************************************
      */}

      {/* Level Navigation Cards (Stream Courses) */}
      {selectedStream && (
        // REF ADDED HERE
        <div className="cm_level-nav" ref={levelNavRef}>
          
         
             {/* NEW FLEX CONTAINER FOR TITLE AND BUTTON */}
            <div className="cm_section-header-flex cm_bottom-border-section">
                {/* cm_section-title-no-border removes the default bottom line from the title */}
                <h3 className="cm_section-title cm_section-title-no-border">{selectedStream} Courses</h3> 
                <button 
                    className="cm_btn-primary cm_btn-primary-small "
                    onClick={() => {
                        setAddLevelOpen(true);
                        setError(null);
                        setSuccess(null);
                    }}
                >
                    <FiPlus /> Add Course Level
                </button>
            </div>
          

          <div className="cm_flex">
            {courseLevels.map((level) => (
              <div
                key={level}
                className={`cm_nav-card ${selectedLevel === level ? "selected_sec" : ""}`}
                onClick={() => handleLevelClick(level)}
              >
                <h3>{level}</h3>
                <p>Manage {level} Courses</p>
              </div>
            ))}
          </div>
        </div>
      )}
      {/* Course Table */}

      {selectedLevel && (
        // REF ADDED HERE to scroll the entire Subject/Table section into view
        <div ref={subjectTableRef}> 
        
        {/* NEW FLEX CONTAINER FOR SUBJECT TITLE AND ACTIONS */}
        <div className="cm_section-header-flex cm_bottom-border-section">
          <h3 className="cm_section-title cm_section-title-no-border">{selectedStream} {selectedLevel} Subjects</h3>
          
          {/* 👇 MODIFIED: Container for search bar and button to keep them grouped */}
          <div className="cm_actions"> 
            {/* 1. SEARCH BAR */}
            <div className="cm_search-bar" style={{ width: '240px' }}>
            {/* The icon is now inside the input field using CSS positioning */}
            <input
                type="text"
                placeholder="Search subjects..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
            />
            {/* The search icon is placed immediately after the input */}
            <FiSearch className="cm_search-icon" /> 
            
            {/* {searchTerm && (
                <FiX className="cm_clear-icon" onClick={() => setSearchTerm("")} />
            )} */}
        </div>
            
            {/* 2. ADD SUBJECT BUTTON (AFTER THE SEARCH BAR) */}
            {selectedLevel && (
                <button 
                    className="cm_btn-primary cm_btn-primary-small"
                    onClick={handleAddSubjectClick} // Use the new handler
                >
                    <FiPlus /> Add Subject
                </button>
            )}
          </div>
        </div>
        
        <div className="cm_table-wrapper">
          {loading ? (
            <p className="cm_loading-message">Loading courses...</p>
          ) : filteredCourses.length === 0 ? (
            <p className="cm_loading-message">No courses found for this level. Add a new subject using the "Add Subject" button above.</p>
          ) : (
            <div className="cm_pro-table-container">
                          <table className="cm_pro-data-table">
              <thead>
                <tr>
                  <th>Subject Code</th> 
                  <th>Subject Name</th> 
                  <th>Description</th>
                  <th>Level</th>
                  <th>Assigned Teachers</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredCourses.map((course) => (
                  <tr key={course.id}>
                    <td>{course.subjectCode}</td> 
                    <td>{course.courseName}</td>
                    <td>{course.description}</td>
                    <td><span className="cm_pill">{selectedStream}-{selectedLevel}</span></td>
                    <td className="cm_pill-teacher">
                      {course.assignedTeachers.map(teacherId => {
                          const teacher = teacherOptions.find(t => t.value === teacherId);
                          return teacher ? <span key={teacherId} >{teacher.label}</span> : null;
                      })}
                    </td>
                    <td>
                      <div className="cm_action-buttons">
                        <button className="cm_btn-icon edit" onClick={() => handleEdit(course)}>
                          <FiEdit2 />
                        </button>
                        <button className="cm_btn-icon cm_btn-icon-danger delete" onClick={() => handleDelete(course.id)}>
                          <FiTrash2 />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            </div>
          )}
        </div>
        </div>
      )}

      {/* ORIGINAL ADD/EDIT COURSE MODAL */}
      {addCourseOpen && (
        <div className="cm_model-overlay active" onClick={() => setAddCourseOpen(false)}>
          <div className="cm_model-content" onClick={(e) => e.stopPropagation()}>
            <div className="cm_model-header">
              <h2>{editCourse ? "Edit Subject" : "Add New Subject"}</h2>
               
              <button className="cm_model-close-btn" onClick={() => setAddCourseOpen(false)}>
                <FiX />
              </button>
            </div>
            <form onSubmit={handleSubmit}>
              
              {/* ********************************************** */}
              {/* NEW/MODIFIED FIELDS FOR UNEDITABLE STREAM/LEVEL */}
              
              {/* Stream Field (Uneditable) */}
              <div className="cm_form-group">
                <label>Stream</label>
                <input
                  type="text"
                  name="stream"
                  // Use formData for display, which is set by handleAddSubjectClick or handleEdit
                  value={formData.stream || selectedStream} 
                  disabled 
                  className="cm_input-disabled"
                />
              </div>

              {/* Level Field (Uneditable) */}
              <div className="cm_form-group">
                <label>Linked Course</label>
                <input
                  type="text"
                  name="level"
                  // Concatenate Stream and Level for the 'Linked Course' display
                  value={`${formData.stream || selectedStream} ${formData.level || selectedLevel}`}
                  disabled
                  className="cm_input-disabled"
                />
              </div>
              
              {/* ********************************************** */}


              <div className="cm_form-group">
                <label>Subject Name</label>
                <input
                  type="text"
                  name="courseName"
                  value={formData.courseName}
                  onChange={handleFormChange}
                  required
                />
              </div>

              <div className="cm_form-group">
                <label>Subject Code</label>
                <input
                  type="text"
                  name="subjectCode"
                  value={formData.subjectCode}
                  onChange={handleFormChange}
                  placeholder="e.g., CA-101"
                  required
                />
              </div>

              <div className="cm_form-group">
                <label>Description (Notes)</label> 
                <textarea
                  name="description"
                  value={formData.description}
                  onChange={handleFormChange}
                />
              </div>

              {/* ********************************************** */}
              {/* REPLACED TEACHER ASSIGNMENT WITH NEW COMPONENT */}
              <div className="cm_form-group">
                <SearchableDropdown
                    options={teacherOptions}
                    selectedValues={formData.assignedTeachers}
                    onToggle={handleTeacherToggle}
                    label="Assign Instructors"
                />
              </div>
              {/* ********************************************** */}
              
              <div className="cm_modal-actions">
                <button type="button" className="cm_btn-outline" onClick={() => setAddCourseOpen(false)}>
                  Cancel
                </button>
                <button type="submit" className="cm_btn-primary">
                  {editCourse ? <><FiEdit2 /> Save Changes</> : <><FiPlus /> Add Subject</>}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      
      {/* === NEW ADD COURSE LEVEL POPUP (Kept for completeness) === */}
      {addLevelOpen && (
          // Uses the cm_model-overlay class name
          <div className={`cm_model-overlay ${addLevelOpen ? 'active' : ''}`} 
               onClick={() => setAddLevelOpen(false)}
          >
              <div className="cm_model-content" onClick={(e) => e.stopPropagation()}>
                  <div className="cm_model-header">
                      <h2>Add New Course</h2>
                      <button className="cm_model-close-btn" onClick={() => setAddLevelOpen(false)}>
                          <FiX />
                      </button>
                  </div>

                  {error && (
                      <div className="cm_feedback error">
                          <FiAlertTriangle /> {error}
                      </div>
                  )}
                  {success && (
                      <div className="cm_feedback success">
                          <FiCheckCircle /> {success}
                      </div>
                  )}

                  <form onSubmit={handleAddNewCourseLevel} className="cm_modal-form">
                      <div className="cm_form-group">
                          <label>Stream</label>
                          <select
                              name="stream"
                              value={newCourseForm.stream}
                              onChange={handleNewCourseFormChange}
                              required
                              disabled // Stream is controlled by the main selection
                          >
                            {streams.map(s => (
                                <option key={s.name} value={s.name}>{s.name}</option>
                            ))}
                          </select>
                      </div>
                      
                      <div className="cm_form-group">
                          <label>New Course Name</label>
                          <input
                              type="text"
                              name="level"
                              value={newCourseForm.level}
                              onChange={handleNewCourseFormChange}
                              placeholder="Enter New Level Name (e.g., Executive, Final)"
                              required
                          />
                      </div>

                      <div className="cm_modal-actions">
                          <button type="button"
                              className="cm_btn-outline"
                              onClick={() => setAddLevelOpen(false)}>
                              Cancel
                          </button>
                          <button type="submit"
                              className="cm_btn-primary">
                              <FiPlus/> Save Course
                          </button>
                      </div>
                  </form>
              </div>
          </div>
      )}
      {/* ==================================== */}

    </div>
  );
};

export default CourseManagement;